//
//  ViewController.m
//  GpuimageTest
//
//  Created by macs on 2018/8/20.
//  Copyright © 2018年 macs. All rights reserved.
//

#import "ViewController.h"
#import "XJGManager.h"
#import "XJGVideoView.h"

#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define ScreenWidth [UIScreen mainScreen].bounds.size.width

@interface ViewController ()<XJGVideoViewDelegate,AgoraRtcEngineDelegate>
@property (strong, nonatomic) AgoraRtcEngineKit *agoraKit;
@property (strong, nonatomic)  XJGVideoView *localVideo;
@property (retain, nonatomic)  UIView *remoteVideo;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // 远程视频
    self.remoteVideo=[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    [self.view addSubview:self.remoteVideo];
    
    self.localVideo=[[XJGVideoView alloc]initWithFrame:CGRectMake(ScreenWidth - 100, 30, 80, 136)];
    self.localVideo.delegate = self;
    [self.view addSubview:self.localVideo];
    [self setupVideo];
    [self joinChannel];
   
}

-(AgoraRtcEngineKit *)agoraKit{
    if (!_agoraKit) {
        _agoraKit = [AgoraRtcEngineKit sharedEngineWithAppId:@"4d05caa64b9e4eeeac8041bd7980cf6e" delegate:self];
    }
    return _agoraKit;
}

// Tutorial Step 2
- (void)setupVideo {
    [self.agoraKit enableVideo];
    // Default mode is disableVideo
    
    [self.agoraKit setVideoProfile:AgoraVideoProfileLandscape480P_4 swapWidthAndHeight: YES];
    [self.agoraKit setExternalVideoSource:YES useTexture:YES pushMode:YES];
    
    // Default video profile is 360P
}


// Tutorial Step 4
- (void)joinChannel {
    __weak typeof(self) weakSelf = self;
    [self.agoraKit setLogFile:@"agoLog"];
    [self.agoraKit joinChannelByToken:nil channelId:@"demoChannel1231111" info:nil uid:1 joinSuccess:^(NSString *channel, NSUInteger uid, NSInteger elapsed) {
        // Join channel "demoChannel1"
        
        [weakSelf.agoraKit setEnableSpeakerphone:YES];
        [UIApplication sharedApplication].idleTimerDisabled = YES;
    }];
    // The UID database is maintained by your app to track which users joined which channels. If not assigned (or set to 0), the SDK will allocate one and returns it in joinSuccessBlock callback. The App needs to record and maintain the returned value as the SDK does not maintain it.
    //    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC);
    //    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
    //        // do something
    //        //NSLog(@"===people_num===%ld",(long)people_num);
    //        if(people_num==0){
    //            [self WaitAnswerZhuboBack];
    //        }
    //    });
    
}

// Tutorial Step 5
- (void)rtcEngine:(AgoraRtcEngineKit *)engine firstRemoteVideoDecodedOfUid:(NSUInteger)uid size: (CGSize)size elapsed:(NSInteger)elapsed {
    if (self.remoteVideo.hidden)
        self.remoteVideo.hidden = false;
    AgoraRtcVideoCanvas *videoCanvas = [[AgoraRtcVideoCanvas alloc] init];
    videoCanvas.uid = uid;
    videoCanvas.view = self.remoteVideo;
    videoCanvas.renderMode = AgoraVideoRenderModeHidden;
    
    [self.agoraKit setupRemoteVideo:videoCanvas];
    
    if (self.remoteVideo.hidden)
        self.remoteVideo.hidden = false;
}



#pragma mark videoViewDelegate

-(void)videoViewWithFrame:(AgoraVideoFrame *)frame{
    BOOL flag = [self.agoraKit pushExternalVideoFrame:frame];
    if (flag) {
        NSLog(@"AgoraVideoFrame == yes");
    }else{
        NSLog(@"AgoraVideoFrame == NO");
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
