//
//  XJGARSDKFilterCollectionViewCell.h
//  XJGARSDK
//
//  Created by gaoyi on 2018/5/9.
//  Copyright © 2018年 gaoyi. All rights reserved.
//

#import <UIKit/UIKit.h>

//@interface XJGARSDKFilterModel : NSObject
//@property (nonatomic, strong)   NSString *filterName;
//@property (nonatomic, strong)   UIImage *filterImage;

//@end

@interface XJGARSDKFilterCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) UIImageView *imageview;
@property (nonatomic, strong) UIImageView *imageviewSelect;
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UILabel *labelSelect;

+ (CGFloat)getFilterCollectionViewCellHeight;
@end
