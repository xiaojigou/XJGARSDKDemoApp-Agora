//
//  MAXJGParameterView.m
//  yuese
//
//  Created by mac on 2018/8/11.
//  Copyright © 2018年 mac. All rights reserved.
//

#import "MAXJGParameterView.h"
#import "MASliderView.h"
#import "XJGARSDKFilterCollectionViewCell.h"
#import "XJGARSDKStickerCollectionViewCell.h"
#import "XJGManager.h"

#define collectionViewHeight  80
#define filterButton_WithHeight 60

@interface MAXJGParameterView()
<MASliderViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource>
/*
 XJGARSDKSetBigEyeParam([slider_bigeye value]);
 XJGARSDKSetRedFaceParam([slider_redface value]);
 XJGARSDKSetWhiteSkinParam([slider_skinwhiten value]);
 XJGARSDKSetSkinSmoothParam([slider_skinsmooth value]);
 XJGARSDKSetThinChinParam([slider_chinsurgery value]);
 */

@property(nonatomic,strong)MASliderView *bigEyeSlider,*redFaceSlider,*whiteSkinSlider,*skinSmoothSlider,*thinChinSlider;

@property(nonatomic,strong)UIView * bgView;
@property(nonatomic,strong)NSArray *filterTitleArray;
@property(nonatomic,strong)NSArray *filterArray;
@property(nonatomic,strong)NSArray *skitertexterarray;
@property(nonatomic,strong)NSArray *skiterPaperArray;
@property (nonatomic, strong) UICollectionView *filtercollectionView;
@property (nonatomic, strong) UICollectionView *stickercollectionView;

@end

@implementation MAXJGParameterView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/



-(UIView*)bgView{
    if (!_bgView) {
        _bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth * 2 / 3, 250)];
        _bgView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
        _bgView.hidden = YES;
        [self setupBgContentView];
    }
    return _bgView;
}

-(MASliderView *)bigEyeSlider{
    if (!_bigEyeSlider) {
        _bigEyeSlider = [[MASliderView alloc] initWithTitle:@"大眼" type:MASliderTypeBigEye];
        _bigEyeSlider.delegate = self;
    }
    return _bigEyeSlider;
}

-(MASliderView *)redFaceSlider{
    if (!_redFaceSlider) {
        _redFaceSlider = [[MASliderView alloc] initWithTitle:@"红润" type:MASliderTypeRedFace];
        _redFaceSlider.delegate = self;
    }
    return _redFaceSlider;
}

-(MASliderView *)whiteSkinSlider{
    if (!_whiteSkinSlider) {
        _whiteSkinSlider = [[MASliderView alloc] initWithTitle:@"美白" type:MASliderTypeWhiteSkin];
        _whiteSkinSlider.delegate = self;
    }
    return _whiteSkinSlider;
}

-(MASliderView *)skinSmoothSlider{
    if (!_skinSmoothSlider) {
        _skinSmoothSlider = [[MASliderView alloc] initWithTitle:@"磨皮" type:MASliderTypeSkinSmooth];
        _skinSmoothSlider.delegate = self;
    }
    return _skinSmoothSlider;
}

-(MASliderView *)thinChinSlider{
    if (!_thinChinSlider) {
        _thinChinSlider = [[MASliderView alloc] initWithTitle:@"瘦脸" type:MASliderTypeThinChin];
        _thinChinSlider.delegate = self;
    }
    return _thinChinSlider;
}

-(NSArray *)filterTitleArray{
    if (!_filterTitleArray) {
        _filterTitleArray = [NSArray arrayWithObjects:[UIImage imageNamed:@"filter_thumb_original"],
                       [UIImage imageNamed:@"filter_thumb_cool"],
                       [UIImage imageNamed:@"filter_thumb_healthy"],
                       [UIImage imageNamed:@"filter_thumb_emerald"],
                       [UIImage imageNamed:@"filter_thumb_nostalgia"],
                       [UIImage imageNamed:@"filter_thumb_crayon.jpg"],
                       [UIImage imageNamed:@"filter_thumb_evergreen"],
                       nil];

    }
    return _filterTitleArray;
}
-(NSArray *)skitertexterarray{
    if (!_skitertexterarray) {
        _skitertexterarray = [NSArray arrayWithObjects:  @"无", @"草莓猫", @"天使",@"罐头狗",@"财神爷",@"潜水",nil];
    }
    return _skitertexterarray;
}

-(NSArray *)filterArray{
    if (!_filterArray) {
        _filterArray = [NSArray arrayWithObjects:@"filter_none",@"filter_cool",@"filter_Healthy",@"filter_emerald",@"filter_nostalgia",@"filter_crayon",@"filter_evergreen", nil];
    }
    return _filterArray;
}

-(NSArray *)skiterPaperArray{
    if (!_skiterPaperArray) {
        _skiterPaperArray = [NSArray arrayWithObjects:@"sticker_none",@"stpaper900224",@"angel",@"cangou",@"caishen",@"diving", nil];
    }
    return _skiterPaperArray;
}


- (UICollectionView *)filtercollectionView
{
    if(_filtercollectionView == nil)
    {
        //创建一个块状表格布局对象
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        //可以左右拉动
        [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
        //横向最小距离
        flowLayout.minimumInteritemSpacing = 5;
        
        //设置 上/左/下/右边距 空间间隔数
        flowLayout.sectionInset = UIEdgeInsetsMake(0, 5, 0, 0);
        
        CGRect frame = CGRectMake([UIScreen mainScreen].bounds.size.width,[UIScreen mainScreen].bounds.size.height -250 , [UIScreen mainScreen].bounds.size.width, collectionViewHeight);
        //创建一个UICollectionview
        _filtercollectionView = [[UICollectionView alloc] initWithFrame:frame collectionViewLayout:flowLayout];
        
        _filtercollectionView.backgroundColor = [UIColor clearColor];
        _filtercollectionView.delegate = self;
        _filtercollectionView.dataSource = self;
        _filtercollectionView.showsHorizontalScrollIndicator = NO;
        [_filtercollectionView registerClass:[XJGARSDKFilterCollectionViewCell class] forCellWithReuseIdentifier:@"filtercell"];
        _filtercollectionView.hidden = YES;
        [self addSubview:_filtercollectionView];
//        [_filtercollectionView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.mas_equalTo(self.mas_right).mas_offset(5);
//            make.right.mas_equalTo(self).mas_offset(-5);
//            make.bottom.mas_equalTo(self);
//            make.height.mas_equalTo(collectionViewHeight);
//
//        }];
        
    }
    return _filtercollectionView;
}


- (UICollectionView *)stickercollectionView
{
    if(_stickercollectionView == nil)
    {
        //创建一个块状表格布局对象
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        //可以左右拉动
        [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
        //横向最小距离
        flowLayout.minimumInteritemSpacing = 5;
        //设置 上/左/下/右边距 空间间隔数
        flowLayout.sectionInset = UIEdgeInsetsMake(0,5, 0, 0);
        
        // CGRect frame = CGRectMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height -250 , [UIScreen mainScreen].bounds.size.width, collectionViewHeight);
        
        CGRect frame = CGRectMake(25, 305 , ScreenWidth, filterButton_WithHeight);
        
        //创建一个UICollectionview
        _stickercollectionView = [[UICollectionView alloc] initWithFrame:frame collectionViewLayout:flowLayout];
        
        _stickercollectionView.backgroundColor = [UIColor clearColor];
        _stickercollectionView.delegate = self;
        _stickercollectionView.dataSource = self;
        _stickercollectionView.showsHorizontalScrollIndicator = NO;
        [_stickercollectionView registerClass:[XJGARSDKStickerCollectionViewCell class] forCellWithReuseIdentifier:@"papercell"];
        _stickercollectionView.hidden = YES;
        [self addSubview:_stickercollectionView];
        __weak typeof(self) weakSelf = self;
        [_stickercollectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(weakSelf.mas_right).mas_offset(5);
            make.right.mas_equalTo(weakSelf).mas_offset(-5);
            make.bottom.mas_equalTo(weakSelf.filtercollectionView).offset(-10);
            make.height.mas_equalTo(filterButton_WithHeight);
            
        }];
        
    }
    return _stickercollectionView;
}



-(void)setupBgContentView{
    __weak typeof(self) weakSelf = self;
    [self addSubview:self.bgView];
//    [self.bgView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.mas_equalTo(weakSelf).mas_offset(5);
//        make.height.mas_equalTo(250);
//        make.width.mas_equalTo(ScreenWidth * 2/3);
//        make.bottom.mas_equalTo(weakSelf.stickercollectionView.mas_top).mas_offset(-10);
//    }];
    [self.bgView addSubview:self.redFaceSlider];
    [self.bgView addSubview:self.whiteSkinSlider];
    [self.bgView addSubview:self.skinSmoothSlider];
    [self.bgView addSubview:self.thinChinSlider];
    [self.bgView addSubview:self.bigEyeSlider];
    [self.redFaceSlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_equalTo(weakSelf.bgView);
        make.height.mas_equalTo(50);
    }];
    [self.whiteSkinSlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.redFaceSlider.mas_bottom);
        make.left.right.mas_equalTo(weakSelf.bgView);
        make.height.mas_equalTo(50);
    }];
    [self.skinSmoothSlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.whiteSkinSlider.mas_bottom);
        make.left.right.mas_equalTo(weakSelf.bgView);
        make.height.mas_equalTo(50);
    }];
    [self.thinChinSlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.skinSmoothSlider.mas_bottom);
        make.left.right.mas_equalTo(weakSelf.bgView);
        make.height.mas_equalTo(50);
    }];
    [self.bigEyeSlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.thinChinSlider.mas_bottom);
        make.left.right.bottom.mas_equalTo(weakSelf.bgView);
        make.height.mas_equalTo(50);
    }];
}

-(void)showSliderView{
//    self.backgroundColor = [UIColor redColor];
    if (self.bgView.hidden) {
        self.bgView.hidden = NO;
        [UIView animateWithDuration:0.3 animations:^{
            [self.bgView mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(self).mas_offset(5);
                make.height.mas_equalTo(250);
                make.width.mas_equalTo(ScreenWidth * 2/3);
                make.bottom.mas_equalTo(self.stickercollectionView.mas_top).mas_offset(-10);
            }];
//            self.frame = CGRectMake(0, 0, ScreenWidth, ScreenHeight);
        } completion:nil];
    }else{
        [UIView animateWithDuration:0.3 animations:^{
            [self.bgView mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(self).mas_offset(5);
                make.height.mas_equalTo(250);
                make.width.mas_equalTo(ScreenWidth * 2/3);
                make.bottom.mas_equalTo(self.stickercollectionView.mas_top).mas_offset(-10);
            }];
//            self.frame = CGRectMake(0, ScreenHeight, ScreenWidth, ScreenHeight);
        } completion:^(BOOL finished) {
            self.bgView.hidden = YES;
        }];
    }
}

-(void)showFilterView{
//    return;
    if (self.filtercollectionView.hidden) {
        self.filtercollectionView.hidden = NO;
        self.stickercollectionView.hidden = NO;
        [UIView animateWithDuration:0.3 animations:^{
            [self.filtercollectionView mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(self).mas_offset(5);
                make.right.mas_equalTo(self).mas_offset(-5);
                make.bottom.mas_equalTo(self);
                make.height.mas_equalTo(collectionViewHeight);
            }];
            [self.stickercollectionView mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(self).mas_offset(5);
                make.right.mas_equalTo(self).mas_offset(-5);
                make.bottom.mas_equalTo(self.filtercollectionView.mas_top).offset(-5);
                make.height.mas_equalTo(filterButton_WithHeight);
            }];
        }];
    }else{
        [UIView animateWithDuration:0.3 animations:^{
            [self.filtercollectionView mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(self.mas_right).mas_offset(5);
                make.right.mas_equalTo(self).mas_offset(-5);
                make.bottom.mas_equalTo(self);
                make.height.mas_equalTo(collectionViewHeight);
            }];
            [self.stickercollectionView mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(self.mas_right).mas_offset(5);
                make.right.mas_equalTo(self).mas_offset(-5);
                make.bottom.mas_equalTo(self.filtercollectionView).offset(-5);
                make.height.mas_equalTo(filterButton_WithHeight);
            }];
        } completion:^(BOOL finished) {
            self.filtercollectionView.hidden = YES;
            self.stickercollectionView.hidden = YES;
        }];
    }
        
       
}

#pragma mark delegate

-(void)sliderValueChange:(float)value withType:(MASliderType)type{
    NSLog(@"===========%f",value);
    if (type == MASliderTypeBigEye) {
        [[XJGManager sharedManager] setBigEye:value];
    }else if (type == MASliderTypeRedFace) {
        [[XJGManager sharedManager] setRedFace:value];
    }else if (type == MASliderTypeWhiteSkin) {
        [[XJGManager sharedManager] setWhiteSkin:value];
    }else if (type == MASliderTypeSkinSmooth) {
        [[XJGManager sharedManager] setSkinSmooth:value];
    }else{
        [[XJGManager sharedManager] setThinChin:value];
    }
}


#pragma mark - collection
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (collectionView == _filtercollectionView)
    {
        return self.filterTitleArray.count;
    }
    
    if (collectionView == _stickercollectionView)
    {
        return  self.skitertexterarray.count;
    }
    else
    {
        return  1;
        
    }
    
}



- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    
    //通过索引号获取文本标签的名字
    if (collectionView == _filtercollectionView)
    {
        XJGARSDKFilterCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"filtercell" forIndexPath:indexPath];

        // cell.label.text = [XJGARSDKResInterface getFilterNameByFilterIdx:(XJGARSDKFilterType)[indexPath row]];
        
        cell.imageview.image = self.filterTitleArray [indexPath.row];
        return cell;

    }
    
    if (collectionView == _stickercollectionView)
    {
        XJGARSDKStickerCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"papercell" forIndexPath:indexPath];
        //通过索引号获取文本标签的名字
        cell.label.text = self.skitertexterarray [indexPath.row];
        
        //设置cell的背景图片
        cell.imageview.image = [UIImage imageNamed:@"ic_seekbar_smallsize_thumb_light_normal"];
        cell.backgroundView = cell.imageview;
        
        
        cell.imageviewSelect.image = [UIImage imageNamed:@"ic_seekbar_thumb_normal"];
        cell.selectedBackgroundView= cell.imageviewSelect;
        return cell;

        
    }
    return nil;

    
}


- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView == self.filtercollectionView) {
         return CGSizeMake([XJGARSDKFilterCollectionViewCell getFilterCollectionViewCellHeight], [XJGARSDKFilterCollectionViewCell getFilterCollectionViewCellHeight]);
        
    }else{
        return CGSizeMake(filterButton_WithHeight, filterButton_WithHeight);
    }
   
    
}


- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    if(collectionView == _filtercollectionView)
    {
        [[XJGManager sharedManager] changeFilter:self.filterArray[indexPath.row]];
    }

    if (collectionView == _stickercollectionView)
    {
        [[XJGManager sharedManager] changeStickerPapers:self.skiterPaperArray[indexPath.row]];

        // [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    }
    
}


@end
