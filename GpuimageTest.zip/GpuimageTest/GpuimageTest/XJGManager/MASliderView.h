//
//  MASliderView.h
//  yuese
//
//  Created by mac on 2018/8/11.
//  Copyright © 2018年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 XJGARSDKSetBigEyeParam([slider_bigeye value]);
 XJGARSDKSetRedFaceParam([slider_redface value]);
 XJGARSDKSetWhiteSkinParam([slider_skinwhiten value]);
 XJGARSDKSetSkinSmoothParam([slider_skinsmooth value]);
 XJGARSDKSetThinChinParam([slider_chinsurgery value]);
 */

typedef NS_ENUM(NSInteger,MASliderType){
    MASliderTypeRedFace,
    MASliderTypeWhiteSkin,
    MASliderTypeSkinSmooth,
    MASliderTypeThinChin,
    MASliderTypeBigEye
};
@protocol MASliderViewDelegate <NSObject>

-(void)sliderValueChange:(float)value withType:(MASliderType)type;

@end

@interface MASliderView : UIView

@property(nonatomic,weak)id<MASliderViewDelegate>delegate;

-(instancetype)initWithTitle:(NSString *)title type:(MASliderType)type;

@end
