//
//  XJGARSDKStickerCollectionViewCell.m
//  XJGARSDK
//
//  Created by gaoyi on 2018/5/17.
//  Copyright © 2018年 gaoyi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XJGARSDKStickerCollectionViewCell.h"

@implementation XJGARSDKStickerCollectionViewCell





- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
//        [self addSubview:self.imageview];
//        [self addSubview:self.imageviewSelect];
        [self addSubview:self.label];
        self.imageview.frame = self.contentView.bounds;
        self.label.frame= CGRectMake(0, 20, self.contentView.bounds.size.width, 20);
        self.imageviewSelect.frame = self.contentView.bounds;
    }
    return self;
}





#pragma mark - lazy
+ (CGFloat)getFilterCollectionViewCellHeight
{
    return 60+20;
}

- (UIImageView *)imageview {
    if (!_imageview) {
        _imageview = [[UIImageView alloc] init];
      //  _imageview.contentMode = UIViewContentModeScaleToFill;
        
    }
    return _imageview;
}

- (UIImageView *)imageviewSelect {
    if (!_imageviewSelect) {
        _imageviewSelect = [[UIImageView alloc] init];
     //   _imageviewSelect.contentMode = UIViewContentModeScaleToFill;
        
    }
    return _imageviewSelect;
}

- (UILabel *)label {
    if (!_label) {
        _label = [[UILabel alloc] init];
        _label.textColor = [UIColor lightGrayColor];
        _label.font = [UIFont systemFontOfSize:12.0];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.lineBreakMode = NSLineBreakByTruncatingTail;
    }
    return _label;
}

@end



