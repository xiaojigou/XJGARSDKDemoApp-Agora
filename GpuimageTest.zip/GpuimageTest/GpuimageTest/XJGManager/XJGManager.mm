//
//  XJGManager.m
//  yuese
//
//  Created by mac on 2018/8/5.
//  Copyright © 2018年 mac. All rights reserved.
//

#import "XJGManager.h"
#import "XJGArSdk.h"

#define XJGRedFace @"XJGRedFace"
#define XJGWhiteSkin @"XJGWhiteSkin"
#define XJGSkinSmooth @"XJGSkinSmooth"
#define XJGThinChin @"XJGThinChin"
#define XJGBigEye @"XJGBigEye"
#define XJGSetFlag @"XJGSetFlag"//是否已经设置了值，如果没有设置的话，都取50

//using namespace std;

@implementation XJGManager
+ (instancetype)sharedManager {
    static id sharedInstance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    
    return sharedInstance;
}

//将模型文件从资源库复制到Documents目录，由于在沙盒里只有Documents目录是可读写的
-(NSString*) copyFile2Documents:(NSString*)fileName filetype:(NSString*) ftype
{
    NSFileManager*fileManager =[NSFileManager defaultManager];
    NSError*error;
    NSArray*paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString*documentsDirectory =[paths objectAtIndex:0];
    
    NSString*destPath1 =[documentsDirectory stringByAppendingPathComponent:fileName];
    NSString*destPath2 =[destPath1 stringByAppendingString:@"."];
    NSString*destPath  =[destPath2 stringByAppendingString:ftype];
    
    //  如果目标目录也就是(Documents)目录没有文件的时候，才会复制一份，否则不复制
    if(![fileManager fileExistsAtPath:destPath]){
        // 设置文件路径
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"resbundle"  ofType:@"bundle"];
        NSString *sourcePath1 = [bundlePath  stringByAppendingPathComponent:fileName];
        NSString *sourcePath2 = [sourcePath1 stringByAppendingString:@"."];
        NSString *sourcePath  = [sourcePath2 stringByAppendingString:ftype];
        
        NSLog(@"sourcePath：%@", sourcePath);
        NSLog(@"destPath：%@", destPath);
        
        BOOL ret = [fileManager copyItemAtPath:sourcePath toPath:destPath error:&error];
        
        NSLog(@"ret:%@", @(ret));
        
        NSLog(@"error:%@", error);
        
    }
    return destPath;
}


//将模型文件从资源库复制到Documents下指定目录中，由于在沙盒里只有Documents目录是可读写的
-(NSString*) copyFile2DirOfDocument:(NSString*)dirName fileName:(NSString*)fileName fileType:(NSString*) ftype
{
    NSFileManager*fileManager =[NSFileManager defaultManager];
    NSError*error;
    
    NSString*destPath1 =[dirName stringByAppendingPathComponent:fileName];
    NSString*destPath2 =[destPath1 stringByAppendingString:@"."];
    NSString*destPath  =[destPath2 stringByAppendingString:ftype];
    
    //  如果目标目录也就是(Documents)目录没有文件的时候，才会复制一份，否则不复制
    if(![fileManager fileExistsAtPath:destPath]){
        // 设置文件路径
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"resbundle"  ofType:@"bundle"];
        NSString *sourcePath1 = [bundlePath  stringByAppendingPathComponent:fileName];
        NSString *sourcePath2 = [sourcePath1 stringByAppendingString:@"."];
        NSString *sourcePath  = [sourcePath2 stringByAppendingString:ftype];
        
        NSLog(@"sourcePath：%@", sourcePath);
        NSLog(@"destPath：%@", destPath);
        
        [fileManager copyItemAtPath:sourcePath toPath:destPath error:&error];
    }
    return destPath;
}


-(void)start{
    
    //复制bundle中的人脸检测与对齐模型文件
    [self copyFile2Documents:@"com.xjg.facedet.model" filetype:@"bin"];
    [self copyFile2Documents:@"com.xjg.landmark.model.100-50-10-5percent.L1000.0-F5-12-4-1.0-2-2-2iter3" filetype:@"bin"];
    [self copyFile2Documents:@"ResForShader" filetype:@"zip"];
    
    //创建ResForShader目录，复制bundle
    //获得沙盒中Documents文件夹路径
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];
    // 在Documents文件夹中创建文件夹
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *resDirectory = [documentsPath stringByAppendingPathComponent:@"ResForShader"];
    [fileManager createDirectoryAtPath:resDirectory withIntermediateDirectories:YES attributes:nil error:nil];
    //复制图片资源文件
    //[self copyFile2DirOfDocument:resDirectory fileName:@"ResForShader" fileType:@"zip"];
    NSString  * shaderResZipDirName   = [documentsPath stringByAppendingPathComponent:@"ResForShader"];
    NSString  * shaderResZipFileName  = [shaderResZipDirName stringByAppendingString:@".zip"];
    const char* shaderResDName        = [shaderResZipDirName UTF8String];
    const char* shaderResFName        = [shaderResZipFileName UTF8String];
    XJGARSDKUnzipFileToTheFolder(shaderResFName,shaderResDName);
    
    //创建贴纸目录，并拷贝贴纸，然后解压
    NSString *stickerDir = [documentsPath stringByAppendingPathComponent:@"StickerPapers"];
    [fileManager createDirectoryAtPath:stickerDir withIntermediateDirectories:YES attributes:nil error:nil];
    //复制贴纸资源文件
    [self copyFile2DirOfDocument:stickerDir fileName:@"angel" fileType:@"zip"];
    [self copyFile2DirOfDocument:stickerDir fileName:@"caishen" fileType:@"zip"];
    [self copyFile2DirOfDocument:stickerDir fileName:@"cangou" fileType:@"zip"];
    //[self copyFile2DirOfDocument:stickerDir fileName:@"daxiongmao" fileType:@"zip"];
    [self copyFile2DirOfDocument:stickerDir fileName:@"diving" fileType:@"zip"];
    [self copyFile2DirOfDocument:stickerDir fileName:@"stpaper900224" fileType:@"zip"];
    
    //解压缩贴纸资源
    NSString  * stickerpaperDirName  = [stickerDir stringByAppendingPathComponent:@"angel"];
    NSString  * stickerpaperPathName = [stickerpaperDirName stringByAppendingString:@".zip"];
    const char* stickerpaperDName    = [stickerpaperDirName UTF8String];
    const char* stickerpaperPName    = [stickerpaperPathName UTF8String];
    XJGARSDKUnzipFileToTheFolder(stickerpaperPName,stickerpaperDName);
    
    stickerpaperDirName  = [stickerDir stringByAppendingPathComponent:@"caishen"];
    stickerpaperPathName = [stickerpaperDirName stringByAppendingString:@".zip"];
    stickerpaperDName    = [stickerpaperDirName UTF8String];
    stickerpaperPName    = [stickerpaperPathName UTF8String];
    XJGARSDKUnzipFileToTheFolder(stickerpaperPName,stickerpaperDName);
    
    
    stickerpaperDirName  = [stickerDir stringByAppendingPathComponent:@"cangou"];
    stickerpaperPathName = [stickerpaperDirName stringByAppendingString:@".zip"];
    stickerpaperDName    = [stickerpaperDirName UTF8String];
    stickerpaperPName    = [stickerpaperPathName UTF8String];
    XJGARSDKUnzipFileToTheFolder(stickerpaperPName,stickerpaperDName);
    
    //    stickerpaperDirName  = [stickerDir stringByAppendingPathComponent:@"daxiongmao"];
    //    stickerpaperPathName = [stickerpaperDirName stringByAppendingString:@".zip"];
    //    stickerpaperDName    = [stickerpaperDirName UTF8String];
    //    stickerpaperPName    = [stickerpaperPathName UTF8String];
    //    XJGARSDKUnzipFileToTheFolder(stickerpaperPName,stickerpaperDName);
    
    stickerpaperDirName  = [stickerDir stringByAppendingPathComponent:@"diving"];
    stickerpaperPathName = [stickerpaperDirName stringByAppendingString:@".zip"];
    stickerpaperDName    = [stickerpaperDirName UTF8String];
    stickerpaperPName    = [stickerpaperPathName UTF8String];
    XJGARSDKUnzipFileToTheFolder(stickerpaperPName,stickerpaperDName);
    
    stickerpaperDirName  = [stickerDir stringByAppendingPathComponent:@"stpaper900224"];
    stickerpaperPathName = [stickerpaperDirName stringByAppendingString:@".zip"];
    stickerpaperDName    = [stickerpaperDirName UTF8String];
    stickerpaperPName    = [stickerpaperPathName UTF8String];
    XJGARSDKUnzipFileToTheFolder(stickerpaperPName,stickerpaperDName);
    
    
    
    
    NSString * licenseText = @"hMPthC0oBIbtMp515TWb9jZvrLAKWIMvA4Dhf03n51QvnJr7jZowVe86d0WwU0NK9QGRFaXQn628fRu941qyr3FtsI5R7Y6v1XEpL6YvQNWQCkFEt1SAb0hyawimOYf1tfG2lIaNE63c5e+OxXssOVUWvw8tOr2glVwWVzh79NmZMahrnS8l69SoeoXLMKCYlvAt/qJFFk4+6Aq3QvOv3o72fq5p90yty+YWg7o0HirZpMSP9P5/DHYPFqR/ud7twTJ+Yo2+ZzYvodqRQbGG0HseZn8Xpt7fZdFuZbc2HGRMVk56vNDMRlcGZZXAjENk7m2UMhi1ohhuSf4WmIgXCZFiJXvYFByaY625gXKtEI7+b7t81nWQYHP9BEbzURwL";
    const char* rootDir = [documentsPath UTF8String];
    XJGARSDKSetRootDirectory(rootDir);//first set model data root directory. then initialize the sdk
    XJGARSDKInitialization([licenseText UTF8String], "DoctorLuoInvitedUser:lyhz", "LuoInvitedCompany:hengzhong");
    
    BOOL flag = [[NSUserDefaults standardUserDefaults] boolForKey:XJGSetFlag];
    if (!flag) {
        [self setDefaultValue];
    }
    XJGARSDKSetShowStickerPapers(false);
  
}

-(void)setWhiteSkin:(int)value{
    XJGARSDKSetWhiteSkinParam(value);
    [self saveValue:value withType:MASliderTypeWhiteSkin];
}

-(void)setSkinSmooth:(int)value{
    XJGARSDKSetSkinSmoothParam(value);
    [self saveValue:value withType:MASliderTypeSkinSmooth];
}

-(void)setBigEye:(int)value{
    XJGARSDKSetBigEyeParam(value);
    [self saveValue:value withType:MASliderTypeBigEye];
}

-(void)setRedFace:(int)value{
    XJGARSDKSetRedFaceParam(value);
    [self saveValue:value withType:MASliderTypeRedFace];
}

-(void)setThinChin:(int)value{
    XJGARSDKSetThinChinParam(value);
    [self saveValue:value withType:MASliderTypeThinChin];
}

-(void)changeFilter:(NSString *)filter{
    XJGARSDKChangeFilter([filter UTF8String]);
}

-(void)changeStickerPapers:(NSString *)StickerPapers{
    if([StickerPapers isEqualToString:@"sticker_none"])
    {
        XJGARSDKSetShowStickerPapers(false);
    }
    else
    {
        XJGARSDKSetShowStickerPapers(true);
        XJGARSDKChangeStickpaper([StickerPapers UTF8String]);
        
    }
}

-(void)saveValue:(CGFloat)value withType:(MASliderType)type{
    NSString * key = [self getKeyWithType:type];
    [[NSUserDefaults standardUserDefaults] setFloat:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

-(CGFloat)getValueWithType:(MASliderType)type{
    NSString * key = [self getKeyWithType:type];
    CGFloat value = [[NSUserDefaults standardUserDefaults] floatForKey:key];
    return value;
}

-(NSString *)getKeyWithType:(MASliderType)type{
    NSString * key;
    switch (type) {
        case MASliderTypeRedFace:
            key = XJGRedFace;
            break;
        case MASliderTypeWhiteSkin:
            key = XJGWhiteSkin;
            break;
        case MASliderTypeSkinSmooth:
            key = XJGSkinSmooth;
            break;
        case MASliderTypeThinChin:
            key = XJGThinChin;
            break;
        case MASliderTypeBigEye:
            key = XJGBigEye;
            break;
        default:
            break;
    }
    return key;
}

-(void)setDefaultValue{
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:XJGSetFlag];
    [[NSUserDefaults standardUserDefaults] setFloat:50.0 forKey:XJGRedFace];
    [[NSUserDefaults standardUserDefaults] setFloat:50.0 forKey:XJGWhiteSkin];
    [[NSUserDefaults standardUserDefaults] setFloat:50.0 forKey:XJGSkinSmooth];
    [[NSUserDefaults standardUserDefaults] setFloat:50.0 forKey:XJGThinChin];
    [[NSUserDefaults standardUserDefaults] setFloat:50.0 forKey:XJGBigEye];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end
