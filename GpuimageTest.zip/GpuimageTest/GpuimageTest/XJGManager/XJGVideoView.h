//
//  XJGVideoView.h
//  yuese
//
//  Created by mac on 2018/8/11.
//  Copyright © 2018年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AgoraRtcEngineKit/AgoraRtcEngineKit.h>

@protocol XJGVideoViewDelegate <NSObject>
-(void)videoViewWithFrame:(AgoraVideoFrame *)frame;
@end
@interface XJGVideoView : UIView

@property(nonatomic,weak)id<XJGVideoViewDelegate>delegate;

-(void)stopCamera;


-(void)switchCamera;

@end
