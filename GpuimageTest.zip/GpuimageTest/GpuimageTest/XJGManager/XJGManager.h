//
//  XJGManager.h
//  yuese
//
//  Created by mac on 2018/8/5.
//  Copyright © 2018年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MASliderView.h"

@interface XJGManager : NSObject

+ (instancetype)sharedManager;
-(void)start;

-(void)setWhiteSkin:(int)value;
-(void)setSkinSmooth:(int)value;
-(void)setBigEye:(int)value;
-(void)setRedFace:(int)value;
-(void)setThinChin:(int)value;

-(void)changeFilter:(NSString *)filter;
-(void)changeStickerPapers:(NSString *)StickerPapers;

/**
 储存美颜参数

 @param value 参数值
 @param type 参数类型
 */
-(void)saveValue:(CGFloat)value withType:(MASliderType)type;

/**
 获取美颜参数

 @param type 参数类型
 @return 参数值
 */
-(CGFloat)getValueWithType:(MASliderType)type;

@end
