//
//  MAXJGParameterView.h
//  yuese
//
//  Created by mac on 2018/8/11.
//  Copyright © 2018年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MAXJGParameterView : UIView
-(void)showSliderView;
-(void)showFilterView;
@end
