//
//  MASliderView.m
//  yuese
//
//  Created by mac on 2018/8/11.
//  Copyright © 2018年 mac. All rights reserved.
//

#import "MASliderView.h"
#import "XJGManager.h"

@interface MASliderView()
@property(nonatomic,strong)UILabel * titleLabel;
@property(nonatomic,strong)UISlider * slider;
@property(nonatomic,strong)NSString * title;
@property(nonatomic,assign)MASliderType sliderType;
@end

@implementation MASliderView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(instancetype)initWithTitle:(NSString *)title type:(MASliderType)type {
    self = [super init];
    _sliderType = type;
    _title = title;
    if (self) {
        [self setupContent];
    }
    return self;
}

-(void)setupContent{
    self.titleLabel.text = self.title;
    [self addSubview:self.titleLabel];
    [self addSubview:self.slider];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.mas_equalTo(self).mas_offset(5);
        make.width.mas_greaterThanOrEqualTo(0);
        make.height.mas_equalTo(20);
    }];
    [self.slider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self).mas_offset(5);
        make.right.mas_equalTo(self).mas_offset(-5);
        make.bottom.mas_equalTo(self).mas_offset(-5);
    }];
}

-(UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textColor = [UIColor whiteColor];
    }
    return _titleLabel;
}

-(UISlider *)slider{
    if (!_slider) {
        _slider = [UISlider new];
        _slider.thumbTintColor = rgba(254, 53, 127, 1);
        _slider.minimumTrackTintColor = rgba(254, 53, 127, 1);
        [_slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
        _slider.minimumValue = 0.0;
        _slider.maximumValue = 100.0;
        _slider.value = [[XJGManager sharedManager] getValueWithType:self.sliderType];
    }
    return _slider;
}

-(void)sliderValueChanged:(UISlider *)slider{
    if (_delegate &&[_delegate respondsToSelector:@selector(sliderValueChange:withType:)]) {
        [_delegate sliderValueChange:slider.value withType:self.sliderType];
    }
}

@end
