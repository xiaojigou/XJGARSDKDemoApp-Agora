//
//  XJGVideoView.m
//  yuese
//
//  Created by mac on 2018/8/11.
//  Copyright © 2018年 mac. All rights reserved.
//

#import "XJGVideoView.h"
#import "GPUImage.h"
#import "XJGArSdk.h"

@interface XJGVideoView()<GPUImageTextureOutputDelegate,GPUImageVideoCameraDelegate>{
    BOOL _willCapturePicture;
    CIContext *_ciContext;
    CGRect _sourceRect;
}

@property (nonatomic, strong) GPUImageVideoCamera *videoCamera;
@property (nonatomic, strong) GPUImageView *filterView;
@property (nonatomic, strong) GPUImageTextureOutput *textureOutput;
@property (nonatomic, assign) BOOL getImageFlag;

@end

@implementation XJGVideoView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self setUpVideoView];
        [self layoutIfNeeded];
        [self setNeedsLayout];
    }
    return self;
}

-(void)setUpVideoView{

    self.videoCamera = [[GPUImageVideoCamera alloc] initWithSessionPreset:AVCaptureSessionPreset640x480 cameraPosition:AVCaptureDevicePositionFront];
    self.videoCamera.outputImageOrientation = UIInterfaceOrientationPortrait;
    self.videoCamera.horizontallyMirrorFrontFacingCamera = YES;
    self.videoCamera.delegate = self;
    self.filterView = [[GPUImageView alloc] initWithFrame:self.bounds];
//    self.filterView.center = self.center;
    self.filterView.backgroundColor = [UIColor redColor];
    self.filterView.fillMode = kGPUImageFillModePreserveAspectRatioAndFill;
    [self addSubview:self.filterView];
//    [self.videoCamera addTarget:self.filterView];

    [self.videoCamera startCameraCapture];
    [self.videoCamera addTarget:self.textureOutput];
    [self performSelector:@selector(getImage) withObject:nil afterDelay:10];


}

-(GPUImageTextureOutput *)textureOutput{
    if (!_textureOutput) {
        _textureOutput = [GPUImageTextureOutput new];
        _textureOutput.delegate = self;
    }
    return _textureOutput;
}

-(void)newFrameReadyFromTextureOutput:(GPUImageTextureOutput *)callbackTextureOutput{
    
    int outPutTexId = 0;
    XJGARSDKRenderGLTexture(callbackTextureOutput.texture,callbackTextureOutput.size.width, callbackTextureOutput.size.height, &outPutTexId);
    if (self.delegate) {
        [self getPixelBufferWithTextureID:outPutTexId size:callbackTextureOutput.size timeStamp:callbackTextureOutput.frameTime];
    }
    GPUImageTextureInput * input = [[GPUImageTextureInput alloc] initWithTexture:outPutTexId size:callbackTextureOutput.size];
    [input addTarget:self.filterView];
    [self.filterView setInputRotation:kGPUImageFlipVertical atIndex:0];
    [input processTextureWithFrameTime:callbackTextureOutput.frameTime];
    [input removeAllTargets];

}



-(void)willOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer{
    [self getImageWithCIImage:sampleBuffer];
}

-(void)stopCamera{
    [self.videoCamera removeAllTargets];
    [self.videoCamera stopCameraCapture];
    _videoCamera = nil;
    [_filterView removeFromSuperview];
    _filterView = nil;
    _textureOutput = nil;
    
    return;
}

-(void)switchCamera{
    [self.videoCamera rotateCamera];
}

-(CVPixelBufferRef)createPixelBufferWithSize:(CGSize)size {
    const void *keys[] = {
        kCVPixelBufferOpenGLESCompatibilityKey,
        kCVPixelBufferIOSurfacePropertiesKey,
    };
    const void *values[] = {
        (__bridge const void *)([NSNumber numberWithBool:YES]),
        (__bridge const void *)([NSDictionary dictionary])
    };
    
    OSType bufferPixelFormat = kCVPixelFormatType_32BGRA;
    
    CFDictionaryRef optionsDictionary = CFDictionaryCreate(NULL, keys, values, 2, NULL, NULL);
    
    CVPixelBufferRef pixelBuffer = NULL;
    CVPixelBufferCreate(kCFAllocatorDefault,
                        size.width,
                        size.height,
                        bufferPixelFormat,
                        optionsDictionary,
                        &pixelBuffer);
    
    CFRelease(optionsDictionary);
    
    return pixelBuffer;
}

-(void)getPixelBufferWithTextureID:(int)textureID size:(CGSize)size timeStamp:(CMTime)timeStamp{
    if (!textureID) {
        return;
    }
    CVPixelBufferRef pixelBuffer1 = [self createPixelBufferWithSize: size];
    
    static CIContext *_ciContext;
    CIImage *outputImage = [CIImage imageWithTexture:textureID size:size flipped:YES colorSpace:NULL];
    UIImage * img = [UIImage imageWithCIImage:outputImage];
    NSLog(@"%@",img);
    if( outputImage != nil) {
        if( _ciContext == nil) {
            _ciContext = [CIContext contextWithEAGLContext: [EAGLContext currentContext]  options:@{kCIContextWorkingColorSpace : [NSNull null]} ];
        }
        
        [_ciContext render: outputImage toCVPixelBuffer: pixelBuffer1  bounds:[outputImage extent] colorSpace:NULL];
    }
    if (!pixelBuffer1) {
        return;
    }
    AgoraVideoFrame * videoFrame = [AgoraVideoFrame new];
    videoFrame.format = 12;
    videoFrame.textureBuf = pixelBuffer1;
    videoFrame.time = timeStamp;
    videoFrame.rotation = 180;
    if (self.delegate &&[self.delegate respondsToSelector:@selector(videoViewWithFrame:)]) {
            [self.delegate videoViewWithFrame:videoFrame];
        }
    
    CFRelease(pixelBuffer1);
}


-(void)getImage{
    self.getImageFlag = YES;
    [self performSelector:@selector(getImage) withObject:nil afterDelay:10];
    //    CGSize size = self.filterView.bounds.size;
    //    UIGraphicsBeginImageContextWithOptions(size, NO, [UIScreen mainScreen].scale);
    //    CGRect rect = self.filterView.frame;
    //    [self.filterView drawViewHierarchyInRect:rect afterScreenUpdates:YES];
    //    UIImage *snapshotImage = UIGraphicsGetImageFromCurrentImageContext();
    //    UIGraphicsEndImageContext();
    //     UIImageWriteToSavedPhotosAlbum(snapshotImage, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
}



-(void)getImageWithCIImage:(CMSampleBufferRef )sampleBuffer{
    if (self.getImageFlag) {
        self.getImageFlag = NO;
        CVPixelBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
        CVPixelBufferLockBaseAddress(imageBuffer, 0);
        CIImage *sourceImage = [CIImage imageWithCVPixelBuffer:imageBuffer
                                                       options:nil];
        CIContext *context = [CIContext contextWithOptions:nil];
        
        CGImageRef cgImage = [context createCGImage:sourceImage fromRect:[sourceImage extent]];
        UIImage *uiImage =[UIImage imageWithCGImage:cgImage];

        UIImageWriteToSavedPhotosAlbum(uiImage, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
    }
    
    
}

- (void)image: (UIImage *) image didFinishSavingWithError: (NSError *) error contextInfo: (void *) contextInfo
{
    NSString *msg = nil ;
    if(error != NULL){
        msg = @"保存图片失败" ;
    }else{
        msg = @"保存图片成功" ;
    }
}


- (void)dealloc
{

}

@end
