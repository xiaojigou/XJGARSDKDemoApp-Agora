package com.beauty.agorabeauty;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.live.meiyan.BeautyManager;
import com.live.meiyan.LuoGLCameraView;
import com.xiaojigou.luo.xjgarsdk.XJGArSdkApi;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.microedition.khronos.egl.EGLContext;

import io.agora.rtc.Constants;
import io.agora.rtc.IRtcEngineEventHandler;
import io.agora.rtc.RtcEngine;
import io.agora.rtc.video.AgoraVideoFrame;
import io.agora.rtc.video.VideoCanvas;

public class MainActivity extends Activity {


    private BeautyManager beautyManger;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        beautyManger = new BeautyManager();

        exceptionInit();
        initBeauty();
    }

    private void initBeauty() {
        String licenseText = "hMPthC0oBIbtMp515TWb9jZvrLAKWIMvA4Dhf03n51QvnJr7jZowVe86d0WwU0NK9QGRFaXQn628fRu941qyr3FtsI5R7Y6v1XEpL6YvQNWQCkFEt1SAb0hyawimOYf1tfG2lIaNE63c5e+OxXssOVUWvw8tOr2glVwWVzh79NmZMahrnS8l69SoeoXLMKCYlvAt/qJFFk4+6Aq3QvOv3o72fq5p90yty+YWg7o0HirZpMSP9P5/DHYPFqR/ud7twTJ+Yo2+ZzYvodqRQbGG0HseZn8Xpt7fZdFuZbc2HGRMVk56vNDMRlcGZZXAjENk7m2UMhi1ohhuSf4WmIgXCZFiJXvYFByaY625gXKtEI7+b7t81nWQYHP9BEbzURwL";
        XJGArSdkApi.XJGARSDKInitialization(this,licenseText,"DoctorLuoInvitedUser:lyhz", "LuoInvitedCompany:hengzhong");


    }

    public void onBeautySet(View view) {

        beautyManger.jumpBeautySettingActivity(this);
    }

    public void onStartVideo(View view) {
        Intent intent = new Intent();
        intent.setClass(this, VideoActivity.class);
        startActivity(intent);
    }

    public void exceptionInit() {
        Thread.setDefaultUncaughtExceptionHandler(new MyUncaughtExceptionHandler());
    }
}

class MyUncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {

    private String getStackInfo(Throwable e) {
        String info;
        Writer writer = new StringWriter();
        PrintWriter pw = new PrintWriter(writer);
        e.printStackTrace(pw);
        info = writer.toString();
        pw.close();
        try {
            writer.close();
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        return info;
    }

    /**
     * 写文件
     * @param string
     */
    public static void writeFile(String string) {
        String path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/test/";
        File dir=new File(path);
        if(!dir.exists()){
            dir.mkdirs();
        }
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String filename=df.format(new Date())+"test.txt";
        FileOutputStream outputStream;
        try {
            File text=new File(path+filename);
            outputStream = new FileOutputStream(text,true);
            outputStream.write(string.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private synchronized void sendToLog(Thread t, Throwable ex) {

        String strException = getStackInfo(ex);
        writeFile(strException);
        Log.e("TTT",strException);

    }
    @Override
    public void uncaughtException(Thread t, Throwable e) {
        // TODO Auto-generated method stub
        sendToLog(t,e);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
