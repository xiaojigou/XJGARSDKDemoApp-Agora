package com.beauty.agorabeauty;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.SurfaceView;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.live.meiyan.BeautyFilter;
import com.live.meiyan.FilterStickerInfo;
import com.live.meiyan.LuoGLCameraView;
import com.live.meiyan.ZIP;
import com.xiaojigou.luo.xjgarsdk.XJGArSdkApi;

import java.io.File;

import javax.microedition.khronos.egl.EGLContext;

import io.agora.rtc.Constants;
import io.agora.rtc.IRtcEngineEventHandler;
import io.agora.rtc.RtcEngine;
import io.agora.rtc.video.AgoraVideoFrame;
import io.agora.rtc.video.VideoCanvas;

/**
 * Created by Administrator on 2018\11\13 0013.
 */

public class VideoActivity extends Activity {

    String[] permissions = new String[] {Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE};
    int requestCode = 200;

    private FrameLayout localContainer;
    private FrameLayout remoteContainer;
    private RtcEngine mRtcEngine;
    private LuoGLCameraView mCustomizedCameraRenderer;
    private boolean hasEnterRoom = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        if(PermissionManager.checkPermissions(this, permissions)) {
            init();
        } else {
            PermissionManager.requestPermissions(this, permissions, requestCode, new PermissionListener() {
                @Override
                public void onAllPermissionGranted() {
                    init();
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        PermissionManager.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void init() {
        try {
            initUIandEvent();
            initAgora();
        } catch (Exception e) {

        }
    }

    private void initUIandEvent() {
        localContainer = (FrameLayout)findViewById(R.id.local_container);
        remoteContainer = (FrameLayout)findViewById(R.id.remote_container);

        loadMeiyanSetting();
    }



    private void initAgora() throws Exception {
        initializeAgoraEngine(this);
        setupVideoProfile(this);
        setupLocalVideo(this);
        mRtcEngine.setClientRole(Constants.CLIENT_ROLE_BROADCASTER);
    }

    private void showLog(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(VideoActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void initializeAgoraEngine(Context context) throws Exception {
        mRtcEngine = RtcEngine.create(context, context.getString(R.string.agora_app_id), mRtcEventHandler);
        mRtcEngine.setChannelProfile(Constants.CHANNEL_PROFILE_LIVE_BROADCASTING);
        mRtcEngine.setParameters("{\"rtc.log_filter\":65535}");
        mRtcEngine.setLogFile(Environment.getExternalStorageState() + File.separator + "rtc_sdk.log");
    }

    private void setupVideoProfile(Context context) throws Exception {
        mRtcEngine.enableVideo();

        if (mRtcEngine.isTextureEncodeSupported()) {
            mRtcEngine.setExternalVideoSource(true, true, true);
        } else {
            throw new RuntimeException("Can not work on device do not supporting texture" + mRtcEngine.isTextureEncodeSupported());
        }
        mRtcEngine.setVideoProfile(Constants.VIDEO_PROFILE_720P, true);
    }

    protected IRtcEngineEventHandler mRtcEventHandler = new IRtcEngineEventHandler() {
        @Override
        public void onFirstRemoteVideoDecoded(final int uid, final int width, final int height, final int elapsed) { // Tutorial Step 5
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    SurfaceView surfaceView = RtcEngine.CreateRendererView(VideoActivity.this);
                    mRtcEngine.setupRemoteVideo(new VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, uid));
                    remoteContainer.addView(surfaceView);
                }
            });
            showLog(uid+" 的直播画面已就位");
        }

        @Override
        public void onUserOffline(final int uid, final int reason) { // Tutorial Step 7
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    remoteContainer.removeAllViews();
                }
            });
            showLog(uid+" 离开房间");
        }

        @Override
        public void onJoinChannelSuccess(final String channel, final int uid, final int elapsed) {
            showLog(uid+" 自己进入频道");
        }

        @Override
        public void onUserJoined(int uid, int elapsed) {

        }

    };

    protected void setupLocalVideo(Context context) throws Exception {
        Log.v("XXX","setupLocalVideo: "+mCustomizedCameraRenderer);
        if(mCustomizedCameraRenderer == null) {
            mCustomizedCameraRenderer = new LuoGLCameraView(context);
        }
        mCustomizedCameraRenderer.setOnFrameAvailableHandler(new LuoGLCameraView.OnFrameAvailableListener() {
            @Override
            public void onFrameAvailable(int texture, EGLContext eglContext, int rotation) {
                AgoraVideoFrame vf = new AgoraVideoFrame();
                vf.format = AgoraVideoFrame.FORMAT_TEXTURE_2D;
                vf.timeStamp = System.currentTimeMillis();
                vf.stride = 360;
                vf.height = 640;
                vf.textureID = texture;
                vf.syncMode = true;
                vf.eglContext11 = eglContext;
                vf.transform = new float[]{
                        1.0f, 0.0f, 0.0f, 0.0f,
                        0.0f, 1.0f, 0.0f, 0.0f,
                        0.0f, 0.0f, 1.0f, 0.0f,
                        0.0f, 0.0f, 0.0f, 1.0f
                };

                boolean result = false;
                Log.v("TTT", "AgoraLiveBroadcaster-setOnFrameAvailableHandler: "+mRtcEngine);
                if(mRtcEngine != null) {
                    result = mRtcEngine.pushExternalVideoFrame(vf);
                }
            }
        });

        mCustomizedCameraRenderer.setOnEGLContextHandler(new LuoGLCameraView.OnEGLContextListener() {
            @Override
            public void onEGLContextReady(EGLContext eglContext) {

                if (!hasEnterRoom) {
                    try {
                        mRtcEngine.joinChannel(null, "agoratestchannel", "Extra Optional Data", 0);
                    }catch(Exception e) {
                        //onError(-2, Utils.getExceptionStack(e)+"(声网joinChannel()异常)");
                    }
                    hasEnterRoom = true;
                }
            }
        });
        XJGArSdkApi.XJGARSDKSetOptimizationMode(2);
        XJGArSdkApi.XJGARSDKSetShowStickerPapers(false);

        localContainer.addView(mCustomizedCameraRenderer);
    }

    private void loadMeiyanSetting() {

        SharedPreferences preferences = getSharedPreferences("beauty_setting_params", Context.MODE_PRIVATE);
        int shoulian = preferences.getInt("beauty_shoulian", 0);
        int dayan = preferences.getInt("beauty_dayan", 0);
        int mopi = preferences.getInt("beauty_mopi", 0);
        int meibai = preferences.getInt("beauty_meibai", 0);
        int hongrun = preferences.getInt("beauty_hongrun", 0);
        String vFilter = preferences.getString("beauty_filter", "");
        if(vFilter.isEmpty()) {
            vFilter = FilterStickerInfo.getFilterInfo(this, BeautyFilter.FILTER_NORMAL);
        }
        String tieZhi = preferences.getString("beauty_tiezhi", "");
//        if(tieZhi.isEmpty()) {
//            tieZhi =
//        }

//        mFaceSurgeryFaceShapeSeek.setProgress(shoulian);
//        mFaceSurgeryBigEyeSeek.setProgress(dayan);
//        mSkinSmoothSeek.setProgress(mopi);
//        mSkinWihtenSeek.setProgress(meibai);
//        mRedFaceSeek.setProgress(hongrun);

        // 将默认美颜参数设置到小吉狗SDK
        XJGArSdkApi.XJGARSDKSetRedFaceParam(hongrun);
        XJGArSdkApi.XJGARSDKSetWhiteSkinParam(meibai);
        XJGArSdkApi.XJGARSDKSetSkinSmoothParam(mopi);
        XJGArSdkApi.XJGARSDKSetThinChinParam(shoulian);
        XJGArSdkApi.XJGARSDKSetBigEyeParam(dayan);
        if(vFilter.isEmpty() == false) {
            XJGArSdkApi.XJGARSDKChangeFilter(vFilter);
        }
        if(tieZhi.isEmpty() == false) {
            String stickerPaperdir = XJGArSdkApi.getPrivateResDataDir(getApplicationContext());
            stickerPaperdir = stickerPaperdir +"/StickerPapers/"+ tieZhi;
            ZIP.unzipAStickPaperPackages(stickerPaperdir);
            XJGArSdkApi.XJGARSDKSetShowStickerPapers(true);
            XJGArSdkApi.XJGARSDKChangeStickpaper(tieZhi);
        } else {
            XJGArSdkApi.XJGARSDKSetShowStickerPapers(false);
        }
    }

    @Override
    public void onBackPressed() {
        mRtcEngine.leaveChannel();
        hasEnterRoom = false;
        RtcEngine.destroy();
        super.onBackPressed();
    }
}
