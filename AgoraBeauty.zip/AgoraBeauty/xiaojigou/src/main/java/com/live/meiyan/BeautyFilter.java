package com.live.meiyan;

/**
 * Created by Administrator on 2018\10\11 0011.
 */

public enum BeautyFilter {

    FILTER_NORMAL,      // 正常
    FILTER_COOL,        // 冷调
    FILTER_HEALTHY,     // 健康
    FILTER_EMERALD,     //
    FILTER_EVERGREEN,
    FILTER_NOSTALGIA,
    FILTER_CRAYON
}
