package com.live.meiyan;

/**
 * Created by Administrator on 2018\10\11 0011.
 */

public enum BeautySticker {

    STICKER_NONE,   // 无
    STICKER_TIANSHI,    // 天使
    STICKER_CAISHENYE,  // 财神爷
    STICKER_GUANTOUGOU, // 罐头狗
    STICKER_QIANSHUIJING, // 潜水镜
    STICKER_HUAHUAN,    // 花环
    STICKER_LEISI,  // 蕾丝
    STICKER_LUFEI,  // 路飞
    STICKER_LUHUA,  // 鹿花
    STICKER_MENGTU, // 梦兔
    STICKER_XUEZUNV,    // 血族女
    STICKER_XIGUAMAO   // 西瓜猫
}
