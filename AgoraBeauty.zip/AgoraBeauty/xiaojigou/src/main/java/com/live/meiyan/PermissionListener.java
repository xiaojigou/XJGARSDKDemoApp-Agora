package com.live.meiyan;

/**
 * Created by Administrator on 2018\9\21 0021.
 */

public abstract class PermissionListener {
    public abstract void onAllPermissionGranted();
    public void onPermissionGranted(String permission, int requestCode){};
    public void onPermissionDenied(String permission, int requestCode){};
}
