package com.live.meiyan;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.opengl.GLES20;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;

//import com.seu.magicfilter.utils.MagicFilterType;
import com.xiaojigou.luo.xjgarsdk.XJGArSdkApi;

//import net.ossrs.yasea.SrsCameraView;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.opengles.GL10;

//import com.xiaojigou.luo.camfilter.CameraEngine;
//import com.xiaojigou.luo.camfilter.LuoGPUCameraInputFilter;
//import com.xiaojigou.luo.camfilter.LuoGPUImgBaseFilter;
//import com.xiaojigou.luo.camfilter.SavePictureTask;
//import com.xiaojigou.luo.camfilter.utils.OpenGlUtils;
//import com.xiaojigou.luo.xjgarsdk.XJGArSdkApi;
//import com.xiaojigou.luo.xjgarsdk.XJGArSdkApi;

public class LuoGLCameraView extends LuoGLBaseView {

    private LuoGPUCameraInputFilter cameraInputFilter;

    // GLSurface截图功能
    private boolean bSavePic = false;   // 是否开始执行截图
    private boolean bSavePicBusy = false;   // 一次截图是否
    private String fileImgPath;
    private SavePicListener savePicListener;

    private SurfaceTexture surfaceTexture;

    public LuoGLCameraView(Context context) {
        //this(context, null);
        super(context);
        Log.v("XXX","++LuoGLCameraView(+)");
        this.getHolder().addCallback(this);//获取surfaceholder对象，并设置回调函数
        scaleType = ScaleType.CENTER_CROP;//设置相机的缩放类型
        XJGArSdkApi.XJGARSDKReleaseAllOpenglResources();
        Log.v("XXX","--LuoGLCameraView(+)");
    }

    public LuoGLCameraView(Context context, AttributeSet attrs) {
        super(context, attrs);//基类的Opengl初始化工作
        Log.v("TTT","++LuoGLCameraView(==)");
        this.getHolder().addCallback(this);//获取surfaceholder对象，并设置回调函数
        scaleType = ScaleType.CENTER_CROP;//设置相机的缩放类型
        XJGArSdkApi.XJGARSDKReleaseAllOpenglResources();
        Log.v("TTT","--LuoGLCameraView(==)");
        //init();
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        super.onSurfaceCreated(gl, config);//基类关于Opengl初始化的一些设置
        Log.v("XXX","++LuoGLCameraView-onSurfaceCreated()");
        if(cameraInputFilter == null)
            cameraInputFilter = new LuoGPUCameraInputFilter();
        cameraInputFilter.init();

        if(filter == null)
            filter = new LuoGPUImgBaseFilter();
        filter.init();

        if (textureId == OpenGlUtils.NO_TEXTURE) {
            textureId = OpenGlUtils.getExternalOESTextureID();
            if (textureId != OpenGlUtils.NO_TEXTURE) {
                surfaceTexture = new SurfaceTexture(textureId);//把opengl纹理对象指定给surfacetexture，surfacetexture在纹理发生变化时，将会将纹理id代表的纹理更新
                surfaceTexture.setOnFrameAvailableListener(onFrameAvailableListener);//设置纹理变化四的监听函数
            }
        }

        //=======================================================
        initCameraTexture();
        Log.v("XXX","--LuoGLCameraView-onSurfaceCreated()");
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {//如果表面发生改变，则先通知基类，基类会通知各个过滤器大小变化了。然后打开相机。
        super.onSurfaceChanged(gl, width, height);
        Log.v("XXX","++LuoGLCameraView-onSurfaceChanged():width="+width+",height="+height);
        pushWidth = width;
        pushHeight = height;
        mGLFboBuffer = IntBuffer.allocate(pushWidth * pushHeight);
        mGLPreviewBuffer = ByteBuffer.allocate(pushWidth * pushHeight * 4);
        openCamera();//打开相机，调整渲染尺寸，通知相机输入纹理尺寸发生变换，并绑定surfacetexture到相机用于预览
        Log.v("XXX","--LuoGLCameraView-onSurfaceChanged()");
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        super.onDrawFrame(gl);//调用基类清除屏幕内容，glClear
        Log.v("TTT","++LuoGLCameraView-onDrawFrame()");
        if(surfaceTexture == null)
            return;
        surfaceTexture.updateTexImage();//从相机中更新纹理内容，
        float[] mtx = new float[16];
        surfaceTexture.getTransformMatrix(mtx);//从surfacetexture中获取纹理变换矩阵（列主序opengles可以直接用）
        cameraInputFilter.setTextureTransformMatrix(mtx);//将输入纹理过滤器的纹理变换矩阵设置为surfacetexture获取的矩阵
        int resultTexture=0;
        resultTexture = cameraInputFilter.onDrawToTexture(textureId,gLCubeBuffer,gLTextureBuffer);
//        int[] resultTex = new int[1];
//        XJGArSdkApi.XJGARSDKRenderGLTexToGLTex(resultTexture,imageWidth,imageHeight,resultTex);
//        resultTexture =  resultTex[0];
//        filter.onDrawFrame(resultTexture,gLCubeBuffer,gLTextureBuffer);

//        XJGArSdkApi.XJGARSDKRenderGLTexture(resultTexture,imageWidth,imageHeight);
        GLES20.glViewport(0,0,surfaceWidth, surfaceHeight);
        int finalTexture = XJGArSdkApi.XJGARSDKRenderGLTexToGLTex(resultTexture,imageWidth,imageHeight);
        GLES20.glViewport(0,0,surfaceWidth, surfaceHeight);
//        filter.onDrawFrame(finalTexture,gLCubeBuffer,gLTextureBuffer);
        filter.onDrawFrame(finalTexture,filter.mGLCubeBuffer,filter.mGLTextureBuffer);

        Log.v("TTT","onDrawFrame()-1");
        //------------------------------------------------------------------------------------------
        // 推流器数据采集 start
        try {
            if (mIsEncoding) {
                Log.v("TTT", "onDrawFrame()-2: "+pushWidth+","+pushHeight+","+mGLFboBuffer.array().length);
                gl.glReadPixels(0, 0, pushWidth, pushHeight, GL10.GL_RGBA, GL10.GL_UNSIGNED_BYTE, mGLFboBuffer);
                Log.v("TTT", "onDrawFrame()-3");
                mGLIntBufferCache.add(mGLFboBuffer);
                Log.v("TTT", "onDrawFrame()-4");
                synchronized (writeLock) {
                    Log.v("TTT", "onDrawFrame()-5");
                    writeLock.notifyAll();
                }
            }
        } catch (Exception e) {
            Log.e("TTT",getExceptionStack(e));
        }
        // 推流器数据采集 start
        //------------------------------------------------------------------------------------------
        Log.v("TTT","onDrawFrame()-6");

        long timer = System.currentTimeMillis();
        timeCounter.add(timer);
        while (start < timeCounter.size() && timeCounter.get(start) < timer - 1000) {
            start++;
        }
        fps = timeCounter.size() - start;
        if (start > 100) {
            timeCounter = timeCounter.subList(start,
                    timeCounter.size() - 1);
            start = 0;
        }
        Log.i("cameraview","fsp:========="+String.valueOf(fps));

        int targetFPS = 30;
        if(fps>targetFPS)
        {
            float targetFrameTime = 1000.f/(float)targetFPS;
            float currentFrameTime = 1000.f/(float)fps;
            float timeToSleep =  targetFrameTime - currentFrameTime;
            if(timeToSleep>1.0)
            {
                try {
                    Thread.sleep((long)timeToSleep);//休眠
                }
                catch (InterruptedException e) {
                }
            }
        }

        //=======================================================
        if (mOnFrameAvailableHandler != null) {
            mOnFrameAvailableHandler.onFrameAvailable(finalTexture, mEGLCurrentContext, 0);
        }

        // 是否需要截图
        try {
            if (bSavePic) {
                bSavePic = false;
                final int w = this.getWidth(), h = this.getHeight(), x = 0, y = 0;
                final int bitmapBuffer[] = new int[w * h];
                final int bitmapSource[] = new int[w * h];
                IntBuffer intBuffer = IntBuffer.wrap(bitmapBuffer);
                intBuffer.position(0);

                gl.glReadPixels(x, y, w, h, GL10.GL_RGBA, GL10.GL_UNSIGNED_BYTE, intBuffer);
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        int offset1, offset2;
                        for (int i = 0; i < h; i++) {
                            offset1 = i * w;
                            offset2 = (h - i - 1) * w;
                            for (int j = 0; j < w; j++) {
                                int texturePixel = bitmapBuffer[offset1 + j];
                                int blue = (texturePixel >> 16) & 0xff;
                                int red = (texturePixel << 16) & 0x00ff0000;
                                int pixel = (texturePixel & 0xff00ff00) | red | blue;
                                bitmapSource[offset2 + j] = pixel;
                                //bitmapSource[i*w+j] = pixel;
                            }
                        }

//                        int[] bmpBuf = {
//                                0xffff0000,0xff00ff00,0xff0000ff,
//                                0xff990000,0xff009900,0xff000099,
//                                0xffffff00,0xff00ffff,0xffff00ff
//                        };
                        Bitmap inBitmap = Bitmap.createBitmap(bitmapSource, w, h, Bitmap.Config.ARGB_8888);
                        //Bitmap inBitmap = Bitmap.createBitmap(bmpBuf, 3, 3, Bitmap.Config.ARGB_8888);
                        //Log.v("DDD","onDrawFrame()-1");
//                        for(int i = 0; i < 3; i++) {
//                            for(int j = 0; j < 3; j++) {
//                                Log.v("DDD","#["+i+","+j+"]: "+String.format("0x%08X",inBitmap.getPixel(i,j)));
//                            }
//                        }
                        //Log.v("DDD","onDrawFrame()-2");
                        inBitmap.getPixel(0,0);
                        //Log.v("DDD","onDrawFrame()-3");
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        inBitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
                        byte[] bitmapdata = bos.toByteArray();
                        ByteArrayInputStream fis = new ByteArrayInputStream(bitmapdata);
                        //Log.v("DDD","onDrawFrame()-4");
                        final Calendar c = Calendar.getInstance();
                        long mytimestamp = c.getTimeInMillis();
                        String timeStamp = String.valueOf(mytimestamp);
                        //String myfile = "hari" + timeStamp + ".jpeg";

//                    dir_image=new File(Environment.getExternalStorageDirectory()+File.separator+
//                            "printerscreenshots"+File.separator+"image");
                        File fileImg = new File(fileImgPath);

                        try {
                            //Log.v("DDD","onDrawFrame()-5");
                            FileOutputStream fos = new FileOutputStream(fileImg);
                            byte[] buf = new byte[1024];
                            int len;
                            while ((len = fis.read(buf)) > 0) {
                                fos.write(buf, 0, len);
                                fos.flush();
                            }
                            fis.close();
                            fos.close();
                            bSavePicBusy = false;
                            //Log.v("DDD","onDrawFrame()-6");
                            savePicListener.onSaveSuccess();
                        } catch (java.io.IOException e) {
                            e.printStackTrace();
                            bSavePicBusy = true;
                            //Log.v("DDD","onDrawFrame()-7: "+e);
                            savePicListener.onSaveFail("写文件失败(" + e.toString() + ")");
                        }
                    }
                }).start();


            }
        }catch(Exception e) {
            Log.e("TTT",e.getMessage());
        }
        Log.v("TTT","--LuoGLCameraView-onDrawFrame()");
    }

    List<Long> timeCounter = new ArrayList<Long>();
    int start = 0;
    int fps =0;

    private SurfaceTexture.OnFrameAvailableListener onFrameAvailableListener
            = new SurfaceTexture.OnFrameAvailableListener() {
        @Override
        public void onFrameAvailable(SurfaceTexture surfaceTexture) {
            requestRender();
        }
    };

    //打开相机，同时通知相机输入过滤器大小发生了变化，然后调整视图与图像的大小，同时设置相机预览的对象为surfacetexture
    private void openCamera() {
        Log.v("XXX","++LuoGLCameraView-openCamera()");
        if(CameraEngine.getCamera() == null)
            CameraEngine.openCamera();
        CameraEngine.CameraEngineInfo info = CameraEngine.getCameraInfo();
        if(info.orientation == 90 || info.orientation == 270){
            imageWidth = info.previewHeight;
            imageHeight = info.previewWidth;
        }else{
            imageWidth = info.previewWidth;
            imageHeight = info.previewHeight;
        }
        cameraInputFilter.onInputSizeChanged(imageWidth, imageHeight);
        cameraInputFilter.initCameraFrameBuffer(imageWidth, imageHeight);
        filter.onInputSizeChanged(imageWidth,imageHeight);

//        adjustSize(info.orientation, info.isFront, true);

        int orientation = info.orientation;
//        orientation = (orientation + 180) %360;
        orientation = (orientation + 180) %360;
        adjustSize(orientation, info.isFront, true);

        if(surfaceTexture != null)
            CameraEngine.startPreview(surfaceTexture);//将表面纹理设置为相机的预览纹理，这样相机图像就会传递给surfacetexture进行处理

        Log.v("XXX","--LuoGLCameraView-openCamera()");
    }

//    private boolean isClosed = false;
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        super.surfaceDestroyed(holder);
        CameraEngine.releaseCamera();
        cameraInputFilter.destroyFramebuffers();
        XJGArSdkApi.XJGARSDKReleaseAllOpenglResources();
    }

//    public synchronized void close() {
//        if(isClosed == false) {
//            isClosed = true;
//            CameraEngine.releaseCamera();
//            cameraInputFilter.destroyFramebuffers();
//            XJGArSdkApi.XJGARSDKReleaseAllOpenglResources();
//        }
//    }

    public void changeRecordingState(boolean isRecording) {
//        recordingEnabled = isRecording;
    }

    @Override
    public void savePicture(final SavePictureTask savePictureTask) {
        CameraEngine.takePicture(null, null, new Camera.PictureCallback() {
            @Override
            public void onPictureTaken(byte[] data, Camera camera) {
                CameraEngine.stopPreview();
                final Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                queueEvent(new Runnable() {
                    @Override
                    public void run() {
                        final Bitmap photo = drawPhoto(bitmap,CameraEngine.getCameraInfo().isFront);
                        GLES20.glViewport(0, 0, bitmap.getWidth(), bitmap.getHeight());
                        if (photo != null) {
                            savePictureTask.execute(photo);
//                            savePictureTask.execute(bitmap);
                        }
                    }
                });
                CameraEngine.startPreview();
            }
        });
    }

    public void getSnapshot(String filePath, SavePicListener listener) {
        Log.v("DDD","getSnapshot()-1");
        savePicListener = listener;
        Log.v("DDD","getSnapshot()-2");
        if(listener != null) {
            Log.v("DDD","getSnapshot()-3");
            if(bSavePicBusy == false) {
                Log.v("DDD","getSnapshot()-4");
                fileImgPath = filePath;
                bSavePic = true;
                bSavePicBusy = true;
            } else {
                Log.v("DDD","getSnapshot()-5");
                listener.onSaveFail("正在截图...");
            }
            Log.v("DDD","getSnapshot()-6");
        }
    }

    private Bitmap drawPhoto(Bitmap bitmap,boolean isRotated){
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Bitmap result;
        if(isRotated)// 自拍相机
            result = XJGArSdkApi.XJGARSDKRenderImage(bitmap,true);
        else
            result = XJGArSdkApi.XJGARSDKRenderImage(bitmap,false);

        return result;
    }

    //============================================================================
    //============================================================================
    //============================================================================
    //============================================================================
    private ByteBuffer mFullQuadVertices;
    private EGLContext mEGLCurrentContext;
    private static class MyContextFactory implements EGLContextFactory {
        private static int EGL_CONTEXT_CLIENT_VERSION = 0x3098;

        private LuoGLCameraView mRenderer;

        public MyContextFactory(LuoGLCameraView renderer) {
            Log.d("TTT", "MyContextFactory " + renderer);
            this.mRenderer = renderer;
        }

        public EGLContext createContext(EGL10 egl, EGLDisplay display, EGLConfig eglConfig) {
            Log.d("TTT", "createContext " + egl + " " + display + " " + eglConfig);
            checkEglError("before createContext", egl);
            int[] attrib_list = {EGL_CONTEXT_CLIENT_VERSION, 2, EGL10.EGL_NONE};

            EGLContext ctx;

            if (mRenderer.mEGLCurrentContext == null) {
                mRenderer.mEGLCurrentContext = egl.eglCreateContext(display, eglConfig,
                        EGL10.EGL_NO_CONTEXT, attrib_list);
                ctx = mRenderer.mEGLCurrentContext;
            } else {
                ctx = mRenderer.mEGLCurrentContext;
            }
            checkEglError("after createContext", egl);
            return ctx;
        }

        public void destroyContext(EGL10 egl, EGLDisplay display, EGLContext context) {
            Log.d("TTT", "destroyContext " + egl + " " + display + " " + context + " " + mRenderer.mEGLCurrentContext);
            if (mRenderer.mEGLCurrentContext == null) {
                egl.eglDestroyContext(display, context);
            }
        }

        private static void checkEglError(String prompt, EGL10 egl) {
            Log.d("TTT", String.format("checkEglError"));
            int error;
            while ((error = egl.eglGetError()) != EGL10.EGL_SUCCESS) {
                Log.d("TTT", String.format("%s: EGL error: 0x%x", prompt, error));
            }
        }
    }

    @Override
    public void init() {
        // Create full scene quad buffer
        final byte FULL_QUAD_COORDS[] = {-1, 1, -1, -1, 1, 1, 1, -1};
        mFullQuadVertices = ByteBuffer.allocateDirect(4 * 2);
        mFullQuadVertices.put(FULL_QUAD_COORDS).position(0);

        setEGLContextFactory(new MyContextFactory(this));

        setPreserveEGLContextOnPause(true);
        setEGLContextClientVersion(2);
        //setRenderer(this);

        //setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);

        //setDebugFlags(DEBUG_LOG_GL_CALLS);
    }

    private OnFrameAvailableListener mOnFrameAvailableHandler;
    public interface OnFrameAvailableListener {
        void onFrameAvailable(int texture, EGLContext eglContext, int rotation);
    }
    public void setOnFrameAvailableHandler(OnFrameAvailableListener listener) {
        this.mOnFrameAvailableHandler = listener;
    }

    private OnEGLContextListener mOnEGLContextHandler;
    public interface OnEGLContextListener {
        void onEGLContextReady(EGLContext eglContext);
    }
    public void setOnEGLContextHandler(OnEGLContextListener listener) {
        this.mOnEGLContextHandler = listener;
    }

    public void initCameraTexture() {
//        try {
//            mOffscreenShader.setProgram(io.agora.tutorials.customizedvideosource.R.raw.vshader, io.agora.tutorials.customizedvideosource.R.raw.fshader, mContext);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        if (mCamera == null) {
//            mCamera = Camera.open(mCameraIndex);
//        }

        if (mOnEGLContextHandler != null) {
            if (mEGLCurrentContext != null) {
                mOnEGLContextHandler.onEGLContextReady(mEGLCurrentContext);
            }
        }

//        // Generate camera texture
//        mSrcTexture.init();
//
//        // Set up SurfaceTexture
//        SurfaceTexture oldSurfaceTexture = mSurfaceTexture;
//        mSurfaceTexture = new SurfaceTexture(mSrcTexture.getTextureId());
//        mSurfaceTexture.setOnFrameAvailableListener(this);
//        if (oldSurfaceTexture != null) {
//            oldSurfaceTexture.release();
//        }
    }

    //============================================================================
    //============================================================================
    //============================================================================
    //============================================================================
    // 推流器使用的接口
    int pushWidth,pushHeight;
    public interface PreviewCallback {
        void onGetRgbaFrame(byte[] data, int width, int height);
    }
    private LuoGLCameraView.PreviewCallback mPrevCb;
    private Thread worker;
    private ConcurrentLinkedQueue<IntBuffer> mGLIntBufferCache = new ConcurrentLinkedQueue<>();
    private volatile boolean mIsEncoding;
    private IntBuffer mGLFboBuffer; // = IntBuffer.allocate(this.getWidth() * this.getHeight());
    private ByteBuffer mGLPreviewBuffer;    // = ByteBuffer.allocate(this.getWidth() * this.getHeight() * 4);
    private final Object writeLock = new Object();

    public void setPreviewCallback(LuoGLCameraView.PreviewCallback cb) {
        mPrevCb = cb;
    }
    public void enableEncoding() {
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!Thread.interrupted()) {
                    while (!mGLIntBufferCache.isEmpty()) {
                        IntBuffer picture = mGLIntBufferCache.poll();
                        mGLPreviewBuffer.asIntBuffer().put(picture.array());
                        mPrevCb.onGetRgbaFrame(mGLPreviewBuffer.array(), pushWidth, pushHeight);
                    }
                    // Waiting for next frame
                    synchronized (writeLock) {
                        try {
                            // isEmpty() may take some time, so we set timeout to detect next frame
                            writeLock.wait(500);
                        } catch (InterruptedException ie) {
                            worker.interrupt();
                        }
                    }
                }
            }
        });
        worker.start();
        mIsEncoding = true;
    }
    public void disableEncoding() {
        mIsEncoding = false;
        mGLIntBufferCache.clear();

        if (worker != null) {
            worker.interrupt();
            try {
                worker.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
                worker.interrupt();
            }
            worker = null;
        }
    }
    public boolean startCamera() {
        openCamera();
        return true;
    }
    public void stopCamera() {
        disableEncoding();

        //stopCamera();
    }
    public int[] setPreviewResolution(int width, int height) {

        return new int[] { width, height };
    }
    public void setPreviewOrientation(int orientation) {}
    public int getCameraId() {return CameraEngine.getCameraInfo().isFront?1:0;}
//    public boolean setFilter(final MagicFilterType type) { return false;}
    public void setCameraId(int id) {}

    public static String getExceptionStack(Exception e) {
        String info;
        Writer writer = new StringWriter();
        PrintWriter pw = new PrintWriter(writer);
        e.printStackTrace(pw);
        info = writer.toString();
        pw.close();
        try {
            writer.close();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return info;
    }
}
