package com.live.meiyan;

import android.content.Context;

import com.qnlive.xiaojigou.R;

//import static com.live.meiyan.BeautyFilter.FILTER_NORMAL;
//import static com.live.meiyan.BeautySticker.STICKER_NONE;
//import static com.live.meiyan.BeautySticker.STICKER_TIANSHI;

/**
 * Created by Administrator on 2018\10\11 0011.
 */

public class FilterStickerInfo {

    public static String getFilterInfo(Context context, BeautyFilter filter) {

        switch (filter) {
            case FILTER_NORMAL:
                return context.getString(R.string.filter_none);
            case FILTER_COOL:
                return context.getString(R.string.filter_cool);
            case FILTER_EMERALD:
                return context.getString(R.string.filter_emerald);
            case FILTER_EVERGREEN:
                return context.getString(R.string.filter_evergreen);
            case FILTER_HEALTHY:
                return context.getString(R.string.filter_healthy);
            case FILTER_NOSTALGIA:
                return context.getString(R.string.filter_nostalgia);
            case FILTER_CRAYON:
                return context.getString(R.string.filter_crayon);
            default:
                return context.getString(R.string.filter_none);
        }
    }

//    public static String getStickerInfo(FilterStickerInfo sticker) {
//
//        if(BeautySticker.STICKER_NONE == sticker) {
//            return "";
//        }
//
//        switch(sticker) {
//            case STICKER_NONE:
//                return "";
//            case STICKER_TIANSHI:
//                return "angel";
//            case STICKER_CAISHENYE:
//                return "caishen";
//            case STICKER_GUANTOUGOU:
//                return "cangou";
//            case STICKER_QIANSHUIJING:
//                return "diving";
//            case STICKER_HUAHUAN:
//                return "huahuan";
//            case STICKER_LEISI:
//                return "leisi";
//            case STICKER_LUFEI:
//                return "lufei";
//            case STICKER_LUFEI:
//                return "lvhua";
//            case STICKER_MENGTU:
//                return "mengtu";
//            case STICKER_XUEZUNV:
//                return "xuezunv";
//            case STICKER_XIGUAMAO:
//                return "stpaper900224";
//            default:
//                return "";
//        }
//    }
}
