package com.live.meiyan;

import android.content.Context;

/**
 * Created by Administrator on 2018\10\11 0011.
 */

public interface BeautyHandler {

    // 磨皮
    public int getMopiParam();
    public void setMopiParam(Context context, int mopi);

    // 美白
    public int getMeibaiParam();
    public void setMeibaiParam(Context context, int meibai);

    // 红润
    public int getHongrunParam();
    public void setHongrunParam(Context context, int hongrun);

    // 瘦脸
    public int getShoulianParam();
    public void setShoulianParam(Context context, int shoulian);

    // 大眼
    public int getDayanParam();
    public void setDayanParam(Context context, int dayan);

    // 滤镜
    public BeautyFilter getFilterParam();
    public void setFilterParam(Context context, BeautyFilter filter);

    // 贴纸
    public BeautySticker getBeautySticker();
    public void setBeautySticker(Context context, BeautySticker sticker);

    public void jumpBeautySettingActivity(Context context);
}
