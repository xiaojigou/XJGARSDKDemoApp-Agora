package com.live.meiyan;

import android.Manifest;
import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;

//import com.live.R;
//import com.live.util.PermissionListener;
//import com.live.util.PermissionManager;
import com.qnlive.xiaojigou.R;
import com.xiaojigou.luo.xjgarsdk.XJGArSdkApi;

import java.util.ArrayList;

/**
 * Created by Administrator on 2018\10\11 0011.
 */

public class BeautySetting extends Activity {

    // 权限申请
    private String[] permissions = {Manifest.permission.CAMERA};
    private int requestCode = 200;

    private GPUCamImgOperator gpuCamImgOperator;
    private SharedPreferences preferences;
    //----------------------------------------------------------------------------------------------
    // 基本美颜参数调整
    private LuoGLCameraView mCustomizedCameraRenderer;
    private SeekBar mFaceSurgeryFaceShapeSeek;      // 瘦脸调整进度条
    private SeekBar mFaceSurgeryBigEyeSeek;         // 大眼调整进度条
    private SeekBar mSkinSmoothSeek;                 // 磨皮调整进度条
    private SeekBar mSkinWihtenSeek;                 // 美白调整进度条
    private SeekBar mRedFaceSeek;                    // 红润调整进度条
    private int shoulian;   // 瘦脸参数值
    private int dayan;      // 大眼参数值
    private int mopi;       // 磨皮参数值
    private int meibai;     // 美白参数值
    private int hongrun;    // 红润参数值
    private String vFilter;     // 滤镜
    private String tieZhi;      // 贴纸


    // 滤镜相关
    private LinearLayout mFilterLayout; // 滤镜布局
    private RecyclerView mFilterListView;   // 滤镜列表
    private FilterRecyclerViewAdapter mAdapter;

    // 贴纸相关
    private ArrayList<MenuBean> mStickerData;
    private RecyclerView mMenuView;
    private MenuAdapter mStickerAdapter;

    // 基本美颜参数相关
    private LinearLayout mFaceSurgeryLayout;    // 基本美颜参数调整面板

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(PermissionManager.checkPermissions(this, permissions) == false) {
            PermissionManager.requestPermissions(this, permissions, requestCode, new PermissionListener() {
                @Override
                public void onAllPermissionGranted() {
                    setContentView(R.layout.activity_camera_with_filter_zhubo);
                    initMeiyan();
                }
            });
        } else {
            setContentView(R.layout.activity_camera_with_filter_zhubo);
            initMeiyan();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        PermissionManager.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void initMeiyan() {
        gpuCamImgOperator = new GPUCamImgOperator();
        LuoGLCameraView luoGLCameraView = (LuoGLCameraView) findViewById(R.id.glsurfaceview_camera);
        mCustomizedCameraRenderer = luoGLCameraView;
        GPUCamImgOperator.context = luoGLCameraView.getContext();
        GPUCamImgOperator.luoGLBaseView = luoGLCameraView;



        initUIandEvent();

        setSavedParam();    // 加载保存的美颜参数值

        //options
//        //optimization mode for video
//        XJGArSdkApi.XJGARSDKSetOptimizationMode(0);
        //optimization mode for video using asychronized thread
        XJGArSdkApi.XJGARSDKSetOptimizationMode(2);
        //show sticker papers
//        XJGArSdkApi.XJGARSDKSetShowStickerPapers(true);
        XJGArSdkApi.XJGARSDKSetShowStickerPapers(false);
    }

    private void setSavedParam() {

        preferences = getSharedPreferences("beauty_setting_params", Context.MODE_PRIVATE);
        shoulian = preferences.getInt("beauty_shoulian", 0);
        dayan = preferences.getInt("beauty_dayan", 0);
        mopi = preferences.getInt("beauty_mopi", 0);
        meibai = preferences.getInt("beauty_meibai", 0);
        hongrun = preferences.getInt("beauty_hongrun", 0);
        vFilter = preferences.getString("beauty_filter", "");
        if(vFilter.isEmpty()) {
            vFilter = FilterStickerInfo.getFilterInfo(this, BeautyFilter.FILTER_NORMAL);
        }
        tieZhi = preferences.getString("beauty_tiezhi", "");
//        if(tieZhi.isEmpty()) {
//            tieZhi =
//        }

        mFaceSurgeryFaceShapeSeek.setProgress(shoulian);
        mFaceSurgeryBigEyeSeek.setProgress(dayan);
        mSkinSmoothSeek.setProgress(mopi);
        mSkinWihtenSeek.setProgress(meibai);
        mRedFaceSeek.setProgress(hongrun);

        // 将默认美颜参数设置到小吉狗SDK
        XJGArSdkApi.XJGARSDKSetRedFaceParam(hongrun);
        XJGArSdkApi.XJGARSDKSetWhiteSkinParam(meibai);
        XJGArSdkApi.XJGARSDKSetSkinSmoothParam(mopi);
        XJGArSdkApi.XJGARSDKSetThinChinParam(shoulian);
        XJGArSdkApi.XJGARSDKSetBigEyeParam(dayan);
        if(vFilter.isEmpty() == false) {
            XJGArSdkApi.XJGARSDKChangeFilter(vFilter);
        }
        if(tieZhi.isEmpty() == false) {
            String stickerPaperdir = XJGArSdkApi.getPrivateResDataDir(getApplicationContext());
            stickerPaperdir = stickerPaperdir +"/StickerPapers/"+ tieZhi;
            ZIP.unzipAStickPaperPackages(stickerPaperdir);
            XJGArSdkApi.XJGARSDKSetShowStickerPapers(true);
            XJGArSdkApi.XJGARSDKChangeStickpaper(tieZhi);
        } else {
            XJGArSdkApi.XJGARSDKSetShowStickerPapers(false);
        }
    }

    private final GPUCamImgOperator.GPUImgFilterType[] types = new GPUCamImgOperator.GPUImgFilterType[]{
            GPUCamImgOperator.GPUImgFilterType.NONE,
            GPUCamImgOperator.GPUImgFilterType.HEALTHY,
            GPUCamImgOperator.GPUImgFilterType.NOSTALGIA,
            GPUCamImgOperator.GPUImgFilterType.COOL,
            GPUCamImgOperator.GPUImgFilterType.EMERALD,
            GPUCamImgOperator.GPUImgFilterType.EVERGREEN,
            GPUCamImgOperator.GPUImgFilterType.CRAYON
    };

    private void initUIandEvent() {
        // 基础美颜参数设置
        mFaceSurgeryLayout = (LinearLayout)findViewById(R.id.layout_facesurgery);
        mFaceSurgeryFaceShapeSeek = (SeekBar)findViewById(R.id.faceShapeValueBar);
        mFaceSurgeryBigEyeSeek = (SeekBar)findViewById(R.id.bigeyeValueBar);
        mSkinSmoothSeek = (SeekBar)findViewById(R.id.skinSmoothValueBar);
        mSkinWihtenSeek = (SeekBar)findViewById(R.id.skinWhitenValueBar);
        mRedFaceSeek = (SeekBar)findViewById(R.id.redFaceValueBar);

        // 滤镜和贴纸
        mFilterLayout = (LinearLayout)findViewById(R.id.layout_filter);
        mFilterListView = (RecyclerView) findViewById(R.id.filter_listView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mFilterListView.setLayoutManager(linearLayoutManager);
        mAdapter = new FilterRecyclerViewAdapter(this, types);
        mFilterListView.setAdapter(mAdapter);
        mAdapter.setOnFilterChangeListener(onFilterChangeListener);

        // 贴纸
        mStickerData=new ArrayList<>();
        mMenuView= (RecyclerView)findViewById(R.id.mMenuView);
        mMenuView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false));
        mStickerAdapter=new MenuAdapter(this,mStickerData);
        mStickerAdapter.setOnClickListener(new ClickUtils.OnClickListener() {
            @Override
            public void onClick(View v, int type, int pos, int child) {
                MenuBean m=mStickerData.get(pos);
                String name=m.name;
                String path = m.path;
                if (name.equals("无")) {
                    XJGArSdkApi.XJGARSDKSetShowStickerPapers(false);
                    tieZhi = "";
                    mStickerAdapter.checkPos=pos;
                    v.setSelected(true);
                }else{
                    String stickerPaperdir = XJGArSdkApi.getPrivateResDataDir(getApplicationContext());
                    stickerPaperdir = stickerPaperdir +"/StickerPapers/"+ path;
                    ZIP.unzipAStickPaperPackages(stickerPaperdir);

                    XJGArSdkApi.XJGARSDKSetShowStickerPapers(true);
                    XJGArSdkApi.XJGARSDKChangeStickpaper(path);
                    tieZhi = path;
                    mStickerAdapter.checkPos=pos;
                    v.setSelected(true);
                }
                mStickerAdapter.notifyDataSetChanged();
            }
        });
        mMenuView.setAdapter(mStickerAdapter);
        initEffectMenu();

        // 瘦脸调节
        mFaceSurgeryFaceShapeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                shoulian = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                XJGArSdkApi.XJGARSDKSetThinChinParam(shoulian);
            }
        });

        // 大眼调节
        mFaceSurgeryBigEyeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                dayan = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                XJGArSdkApi.XJGARSDKSetBigEyeParam(dayan);
            }
        });

        // 磨皮调节
        mSkinSmoothSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                mopi = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                XJGArSdkApi.XJGARSDKSetSkinSmoothParam(mopi);
            }
        });

        // 美白调节
        mSkinWihtenSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public int value;
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                meibai = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                XJGArSdkApi.XJGARSDKSetWhiteSkinParam(meibai);
            }
        });

        // 红润调节
        mRedFaceSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                hongrun = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                XJGArSdkApi.XJGARSDKSetRedFaceParam(hongrun);
            }
        });

        mFilterListView = (RecyclerView) findViewById(R.id.filter_listView);

        findViewById(R.id.btn_camera_switch).setOnClickListener(btn_listener);  // 切换前后摄像头
        findViewById(R.id.btn_camera_beauty).setOnClickListener(btn_listener);  // 基础美颜参数
        findViewById(R.id.btn_camera_filter).setOnClickListener(btn_listener);  // 滤镜和贴纸
        findViewById(R.id.btn_camera_shutter).setOnClickListener(btn_listener); // 保存美颜参数
    }

    /**
     * 控件点击事件
     */
    private static boolean bShowFaceSurgery = false;
    private static boolean bShowImgFilters = false;
    private View.OnClickListener btn_listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            int id = view.getId();

            if(id == R.id.btn_camera_switch) {
                gpuCamImgOperator.switchCamera();
            } else if(id == R.id.btn_camera_beauty) {
                bShowFaceSurgery = ! bShowFaceSurgery;
                showFaceSurgery(bShowFaceSurgery);
            } else if(id == R.id.btn_camera_filter) {
                bShowImgFilters = !bShowImgFilters;
                showFilters(bShowImgFilters);
            } else if(id == R.id.btn_camera_shutter) {  // 保存美颜设置
                preferences.edit().putInt("beauty_hongrun", hongrun).commit();
                preferences.edit().putInt("beauty_meibai", meibai).commit();
                preferences.edit().putInt("beauty_mopi", mopi).commit();
                preferences.edit().putInt("beauty_shoulian", shoulian).commit();
                preferences.edit().putInt("beauty_dayan", dayan).commit();
                preferences.edit().putString("beauty_filter", vFilter).commit();
                preferences.edit().putString("beauty_tiezhi", tieZhi).commit();
                finish();
            }
        }
    };

    private FilterRecyclerViewAdapter.onFilterChangeListener onFilterChangeListener = new FilterRecyclerViewAdapter.onFilterChangeListener(){

        @Override
        public void onFilterChanged(GPUCamImgOperator.GPUImgFilterType filterType) {
//            GPUCamImgOperator.setFilter(filterType);
            String filterName = FilterTypeHelper.FilterType2FilterName(filterType);
            XJGArSdkApi.XJGARSDKChangeFilter(filterName);
            vFilter = filterName;
        }
    };

    /**
     * 是否显示滤镜列表
     *
     * @param isShow        true：显示     false：不显示
     */
    private void showFilters(final boolean isShow){
        ObjectAnimator animator = ObjectAnimator.ofFloat(mFilterLayout, "translationY", isShow?mFilterLayout.getHeight():0, isShow?0:mFilterLayout.getHeight());
        animator.setDuration(200);
        animator.addListener(new Animator.AnimatorListener() {

            @Override
            public void onAnimationStart(Animator animation) {
                //findViewById(R.id.btn_camera_shutter).setClickable(false);
                if(isShow) {
                    mFilterLayout.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if(isShow == false) {
                    mFilterLayout.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                if(isShow == false) {
                    mFilterLayout.setVisibility(View.INVISIBLE);
                }
            }
        });
        animator.start();
    }

    /**
     * 是否显示美颜设置基础面板
     * @param isShow        true：显示     false：不显示
     */
    private void showFaceSurgery(final boolean isShow) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(mFaceSurgeryLayout, "translationY", isShow?mFaceSurgeryLayout.getHeight():0, isShow?0:mFaceSurgeryLayout.getHeight());
        animator.setDuration(200);
        animator.addListener(new Animator.AnimatorListener() {

            @Override
            public void onAnimationStart(Animator animation) {
                if(isShow) {
                    mFaceSurgeryLayout.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if(isShow == false) {
                    mFaceSurgeryLayout.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                if(isShow == false) {
                    mFaceSurgeryLayout.setVisibility(View.INVISIBLE);
                }
            }
        });
        animator.start();
    }

    //初始化特效按钮菜单
    protected void initEffectMenu() {

        MenuBean bean=new MenuBean();
        bean.name="无";
        bean.path="";
        mStickerData.add(bean);

        bean=new MenuBean();
        bean.name="天使";
        bean.path="angel";
        mStickerData.add(bean);

        bean=new MenuBean();
        bean.name="财神爷";
        bean.path="caishen";
        mStickerData.add(bean);

        bean=new MenuBean();
        bean.name="罐头狗";
        bean.path="cangou";
        mStickerData.add(bean);

        bean=new MenuBean();
        bean.name="潜水镜";
        bean.path="diving";
        mStickerData.add(bean);

        bean=new MenuBean();
        bean.name="花环";
        bean.path="huahuan";
        mStickerData.add(bean);

        bean=new MenuBean();
        bean.name="蕾丝";
        bean.path="leisi";
        mStickerData.add(bean);

        bean=new MenuBean();
        bean.name="路飞";
        bean.path="lufei";
        mStickerData.add(bean);

        bean=new MenuBean();
        bean.name="鹿花";
        bean.path="lvhua";
        mStickerData.add(bean);

        bean=new MenuBean();
        bean.name="梦兔";
        bean.path="mengtu";
        mStickerData.add(bean);

        bean=new MenuBean();
        bean.name="血族女";
        bean.path="xuezunv";
        mStickerData.add(bean);


        bean=new MenuBean();
        bean.name=" 西瓜猫";
        bean.path="stpaper900224";
        mStickerData.add(bean);

        mStickerAdapter.notifyDataSetChanged();
    }
}
