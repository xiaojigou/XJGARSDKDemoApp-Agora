package com.live.meiyan;


import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

/**
 * Created by Administrator on 2018\9\21 0021.
 */

public class PermissionManager {

    private static String[] allPermissions;
    private static int requestCode;
    private static PermissionListener permissionListener;
    private static boolean isAllPermissionsGranted = true;

    public static void requestPermissions(Activity context, String[] permissions, int rCode, PermissionListener listener) {
        allPermissions = permissions;
        requestCode = rCode;
        permissionListener = listener;

        ActivityCompat.requestPermissions(context,allPermissions,requestCode);
    }

    public static void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResult) {

        if(requestCode == requestCode) {
            if(permissionListener != null) {
                for(int i = 0; i < permissions.length; i++) {
                    if(grantResult[i] == PackageManager.PERMISSION_GRANTED) {
                        permissionListener.onPermissionGranted(permissions[i], requestCode);
                    } else if(grantResult[i] == PackageManager.PERMISSION_DENIED) {
                        permissionListener.onPermissionDenied(permissions[i], requestCode);
                        isAllPermissionsGranted = false;
                    }
                }

                if(isAllPermissionsGranted) {
                    if(permissionListener != null) {
                        permissionListener.onAllPermissionGranted();
                    }
                }
            }
        }
    }

    public static boolean checkPermissions(Context context, String[] permissions) {

        for(int i = 0; i < permissions.length; i++) {
            if(checkSinglePermission(context, permissions[i]) == false) {
                return false;
            }
        }
        return true;
    }

    public static boolean checkSinglePermission(Context context, String permission) {
        if(ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
            return false;
        } else {
            return true;
        }
    }


}
