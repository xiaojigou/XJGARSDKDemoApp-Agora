package com.live.meiyan;

import android.content.Context;
import android.content.Intent;

/**
 * Created by Administrator on 2018\10\11 0011.
 */

public class BeautyManager implements BeautyHandler {

    @Override
    public int getMopiParam() {
        return 0;
    }

    @Override
    public void setMopiParam(Context context, int mopi) {

    }

    @Override
    public int getMeibaiParam() {
        return 0;
    }

    @Override
    public void setMeibaiParam(Context context, int meibai) {

    }

    @Override
    public int getHongrunParam() {
        return 0;
    }

    @Override
    public void setHongrunParam(Context context, int hongrun) {

    }

    @Override
    public int getShoulianParam() {
        return 0;
    }

    @Override
    public void setShoulianParam(Context context, int shoulian) {

    }

    @Override
    public int getDayanParam() {
        return 0;
    }

    @Override
    public void setDayanParam(Context context, int dayan) {

    }

    @Override
    public BeautyFilter getFilterParam() {
        return null;
    }

    @Override
    public void setFilterParam(Context context, BeautyFilter filter) {

    }

    @Override
    public BeautySticker getBeautySticker() {
        return null;
    }

    @Override
    public void setBeautySticker(Context context, BeautySticker sticker) {

    }

    @Override
    public void jumpBeautySettingActivity(Context context) {
        Intent intent = new Intent();
        intent.setAction( "com.live.maiyansetting");
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        context.startActivity(intent);
    }
}
