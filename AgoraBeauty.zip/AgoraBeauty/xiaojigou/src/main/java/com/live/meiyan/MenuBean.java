/*
 *
 * MenuBean.java
 *
 */
package com.live.meiyan;

/**
 * Description:
 */
public class MenuBean {

    public String name;
    public String path;
    public String show;

    public int id;

}
